#!/bin/bash
echo "Arrêt de VigiTime..."
docker-compose down
echo "✓ Arrêté"
