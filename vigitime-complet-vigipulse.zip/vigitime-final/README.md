# VigiTime SaaS — Système de gestion de présence

## Stack technique

| Couche | Technologie |
|--------|------------|
| Backend | FastAPI (Python 3.12) + SQLAlchemy async |
| Base de données | PostgreSQL 16 + Redis 7 |
| Frontend | React 18 + TypeScript + Vite + TailwindCSS |
| State | Zustand + React Query |
| Auth | JWT (access + refresh tokens) |
| Déploiement | Docker Compose + Nginx |

## Démarrage rapide

### Prérequis
- Docker + Docker Compose
- Node.js 20+ (développement local)
- Python 3.12+ (développement local)

### 1. Configuration
```bash
cp .env.example .env
# Éditer .env avec vos valeurs
```

### 2. Démarrer avec Docker
```bash
docker-compose up -d
```
- Frontend : http://localhost:3000
- API : http://localhost:8000
- Docs API : http://localhost:8000/api/docs

### 3. Développement local (sans Docker)

**Backend :**
```bash
cd backend
pip install -r requirements.txt
alembic upgrade head           # Migrations DB
uvicorn app.main:app --reload  # Serveur dev
```

**Frontend :**
```bash
cd frontend
npm install
npm run dev
```

## Structure du projet
```
vigitime-saas/
├── backend/
│   ├── app/
│   │   ├── api/v1/endpoints/   # Routes FastAPI
│   │   ├── core/               # Config, sécurité, DB
│   │   ├── models/             # SQLAlchemy ORM
│   │   ├── schemas/            # Pydantic schemas
│   │   └── services/           # Logique métier
│   └── alembic/                # Migrations DB
├── frontend/
│   └── src/
│       ├── components/         # UI réutilisables
│       ├── pages/              # Pages React
│       ├── lib/                # API client, stores
│       └── types/              # TypeScript types
└── infra/
    ├── nginx/                  # Reverse proxy
    └── docker/                 # Scripts init DB
```

## Accès démo
| Rôle | Email | Mot de passe |
|------|-------|-------------|
| Super Admin | admin@vigitime.dz | admin123 |
| Responsable RH | rh@vigitime.dz | rh123 |
| Superviseur | sup@vigitime.dz | sup123 |

## API Endpoints
| Méthode | Route | Description |
|---------|-------|-------------|
| POST | /api/v1/auth/login | Connexion |
| GET | /api/v1/employees | Liste employés (paginé) |
| POST | /api/v1/employees | Créer employé |
| PATCH | /api/v1/employees/{id} | Modifier employé |
| DELETE | /api/v1/employees/{id} | Supprimer employé |
| GET | /api/v1/attendance | Pointages (filtré) |
| POST | /api/v1/attendance | Ajouter pointage |
| GET | /api/v1/attendance/stats/{id} | Stats employé |
| POST | /api/v1/attendance/leaves | Demande congé |
| GET | /api/v1/devices | Liste terminaux |
| POST | /api/v1/devices/{id}/ping | Tester terminal |
| POST | /api/v1/devices/{id}/sync | Synchroniser |

## Multi-tenant
Chaque client (entreprise) est isolé par `tenant_id`.
Toutes les tables portent une colonne `tenant_id` avec contrainte FK.
