"""Initial schema

Revision ID: 001
Revises: 
Create Date: 2025-03-18
"""
from alembic import op
import sqlalchemy as sa

revision = '001'
down_revision = None
branch_labels = None
depends_on = None

def upgrade() -> None:
    # tenants
    op.create_table('tenants',
        sa.Column('id',           sa.String(36),  primary_key=True),
        sa.Column('name',         sa.String(200), nullable=False),
        sa.Column('slug',         sa.String(100), nullable=False, unique=True),
        sa.Column('address',      sa.String(500), nullable=True),
        sa.Column('phone',        sa.String(30),  nullable=True),
        sa.Column('email',        sa.String(200), nullable=True),
        sa.Column('logo_url',     sa.String(500), nullable=True),
        sa.Column('timezone',     sa.String(50),  server_default='Africa/Algiers'),
        sa.Column('locale',       sa.String(10),  server_default='fr'),
        sa.Column('currency',     sa.String(10),  server_default='DZD'),
        sa.Column('weekend_days', sa.String(20),  server_default='5,6'),
        sa.Column('plan',         sa.String(50),  server_default='free'),
        sa.Column('is_active',    sa.Boolean(),   server_default='1'),
        sa.Column('max_employees',sa.Integer(),   server_default='50'),
        sa.Column('created_at',   sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',   sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )

    # departments
    op.create_table('departments',
        sa.Column('id',         sa.String(36),  primary_key=True),
        sa.Column('tenant_id',  sa.String(36),  sa.ForeignKey('tenants.id', ondelete='CASCADE'), nullable=False),
        sa.Column('code',       sa.String(20),  nullable=False),
        sa.Column('name',       sa.String(200), nullable=False),
        sa.Column('manager_id', sa.String(36),  nullable=True),
        sa.Column('is_active',  sa.Boolean(),   server_default='1'),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )
    op.create_index('ix_departments_tenant_id', 'departments', ['tenant_id'])

    # positions
    op.create_table('positions',
        sa.Column('id',            sa.String(36),  primary_key=True),
        sa.Column('tenant_id',     sa.String(36),  sa.ForeignKey('tenants.id', ondelete='CASCADE'), nullable=False),
        sa.Column('title',         sa.String(200), nullable=False),
        sa.Column('department_id', sa.String(36),  nullable=True),
        sa.Column('hourly_rate',   sa.Float(),     server_default='312.0'),
        sa.Column('created_at',    sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',    sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )

    # employees
    op.create_table('employees',
        sa.Column('id',              sa.String(36),  primary_key=True),
        sa.Column('tenant_id',       sa.String(36),  sa.ForeignKey('tenants.id', ondelete='CASCADE'), nullable=False),
        sa.Column('matricule',       sa.String(50),  nullable=False),
        sa.Column('first_name',      sa.String(100), nullable=False),
        sa.Column('last_name',       sa.String(100), nullable=False),
        sa.Column('gender',          sa.String(10),  nullable=True),
        sa.Column('birth_date',      sa.Date(),      nullable=True),
        sa.Column('nationality',     sa.String(100), nullable=True),
        sa.Column('national_id',     sa.String(50),  nullable=True),
        sa.Column('social_security', sa.String(50),  nullable=True),
        sa.Column('email',           sa.String(200), nullable=True),
        sa.Column('phone',           sa.String(30),  nullable=True),
        sa.Column('address',         sa.Text(),      nullable=True),
        sa.Column('department_id',   sa.String(36),  sa.ForeignKey('departments.id', ondelete='SET NULL'), nullable=True),
        sa.Column('position_id',     sa.String(36),  sa.ForeignKey('positions.id',   ondelete='SET NULL'), nullable=True),
        sa.Column('hire_date',       sa.Date(),      nullable=True),
        sa.Column('hourly_rate',     sa.Float(),     server_default='312.0'),
        sa.Column('badge_nfc',       sa.String(50),  nullable=True),
        sa.Column('pin_code',        sa.String(10),  nullable=True),
        sa.Column('zkteco_uid',      sa.Integer(),   nullable=True),
        sa.Column('status',          sa.String(20),  server_default='active'),
        sa.Column('photo_url',       sa.String(500), nullable=True),
        sa.Column('created_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )
    op.create_index('ix_employees_tenant_id', 'employees', ['tenant_id'])
    op.create_index('ix_employees_matricule', 'employees', ['tenant_id', 'matricule'], unique=True)
    op.create_index('ix_employees_status',    'employees', ['tenant_id', 'status'])

    # employee_documents
    op.create_table('employee_documents',
        sa.Column('id',          sa.String(36),  primary_key=True),
        sa.Column('tenant_id',   sa.String(36),  sa.ForeignKey('tenants.id',   ondelete='CASCADE'), nullable=False),
        sa.Column('employee_id', sa.String(36),  sa.ForeignKey('employees.id', ondelete='CASCADE'), nullable=False),
        sa.Column('doc_type',    sa.String(50),  nullable=False),
        sa.Column('name',        sa.String(200), nullable=False),
        sa.Column('file_url',    sa.String(500), nullable=False),
        sa.Column('file_size',   sa.Integer(),   nullable=True),
        sa.Column('created_at',  sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',  sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )

    # users
    op.create_table('users',
        sa.Column('id',              sa.String(36),  primary_key=True),
        sa.Column('tenant_id',       sa.String(36),  sa.ForeignKey('tenants.id',   ondelete='CASCADE'), nullable=False),
        sa.Column('email',           sa.String(200), nullable=False),
        sa.Column('hashed_password', sa.String(200), nullable=False),
        sa.Column('full_name',       sa.String(200), nullable=False),
        sa.Column('role',            sa.String(50),  server_default='viewer'),
        sa.Column('avatar_url',      sa.String(500), nullable=True),
        sa.Column('is_active',       sa.Boolean(),   server_default='1'),
        sa.Column('is_verified',     sa.Boolean(),   server_default='0'),
        sa.Column('last_login_at',   sa.String(50),  nullable=True),
        sa.Column('employee_id',     sa.String(36),  sa.ForeignKey('employees.id', ondelete='SET NULL'), nullable=True),
        sa.Column('created_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )
    op.create_index('ix_users_tenant_email', 'users', ['tenant_id', 'email'], unique=True)

    # devices
    op.create_table('devices',
        sa.Column('id',            sa.String(36),  primary_key=True),
        sa.Column('tenant_id',     sa.String(36),  sa.ForeignKey('tenants.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name',          sa.String(100), nullable=False),
        sa.Column('serial_number', sa.String(100), nullable=True),
        sa.Column('model',         sa.String(100), nullable=True),
        sa.Column('brand',         sa.String(50),  nullable=True),
        sa.Column('firmware',      sa.String(50),  nullable=True),
        sa.Column('ip_address',    sa.String(50),  nullable=False),
        sa.Column('port',          sa.Integer(),   server_default='4370'),
        sa.Column('comm_key',      sa.Integer(),   server_default='0'),
        sa.Column('protocol',      sa.String(20),  server_default='zkteco'),
        sa.Column('location',      sa.String(200), nullable=True),
        sa.Column('area',          sa.String(100), nullable=True),
        sa.Column('status',        sa.String(20),  server_default='offline'),
        sa.Column('last_sync_at',  sa.String(50),  nullable=True),
        sa.Column('total_records', sa.Integer(),   server_default='0'),
        sa.Column('is_active',     sa.Boolean(),   server_default='1'),
        sa.Column('created_at',    sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',    sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )

    # timetables
    op.create_table('timetables',
        sa.Column('id',              sa.String(36),  primary_key=True),
        sa.Column('tenant_id',       sa.String(36),  sa.ForeignKey('tenants.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name',            sa.String(100), nullable=False),
        sa.Column('start_time',      sa.Time(),      nullable=False),
        sa.Column('end_time',        sa.Time(),      nullable=False),
        sa.Column('break_minutes',   sa.Integer(),   server_default='60'),
        sa.Column('late_tolerance',  sa.Integer(),   server_default='15'),
        sa.Column('early_tolerance', sa.Integer(),   server_default='15'),
        sa.Column('is_active',       sa.Boolean(),   server_default='1'),
        sa.Column('created_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',      sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )

    # leave_requests
    op.create_table('leave_requests',
        sa.Column('id',               sa.String(36),  primary_key=True),
        sa.Column('tenant_id',        sa.String(36),  sa.ForeignKey('tenants.id',   ondelete='CASCADE'), nullable=False),
        sa.Column('employee_id',      sa.String(36),  sa.ForeignKey('employees.id', ondelete='CASCADE'), nullable=False),
        sa.Column('approved_by',      sa.String(36),  sa.ForeignKey('users.id',     ondelete='SET NULL'), nullable=True),
        sa.Column('leave_type',       sa.String(30),  nullable=False),
        sa.Column('start_date',       sa.Date(),      nullable=False),
        sa.Column('end_date',         sa.Date(),      nullable=False),
        sa.Column('working_days',     sa.Integer(),   server_default='0'),
        sa.Column('reason',           sa.Text(),      nullable=True),
        sa.Column('status',           sa.String(20),  server_default='pending'),
        sa.Column('approved_at',      sa.String(50),  nullable=True),
        sa.Column('rejection_reason', sa.Text(),      nullable=True),
        sa.Column('created_at',       sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',       sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )
    op.create_index('ix_leaves_tenant_emp', 'leave_requests', ['tenant_id', 'employee_id'])

    # attendance_records
    op.create_table('attendance_records',
        sa.Column('id',               sa.String(36), primary_key=True),
        sa.Column('tenant_id',        sa.String(36), sa.ForeignKey('tenants.id',      ondelete='CASCADE'), nullable=False),
        sa.Column('employee_id',      sa.String(36), sa.ForeignKey('employees.id',    ondelete='CASCADE'), nullable=False),
        sa.Column('timetable_id',     sa.String(36), sa.ForeignKey('timetables.id',   ondelete='SET NULL'), nullable=True),
        sa.Column('device_id',        sa.String(36), sa.ForeignKey('devices.id',      ondelete='SET NULL'), nullable=True),
        sa.Column('leave_id',         sa.String(36), sa.ForeignKey('leave_requests.id',ondelete='SET NULL'), nullable=True),
        sa.Column('date',             sa.Date(),     nullable=False),
        sa.Column('check_in',         sa.Time(),     nullable=True),
        sa.Column('check_out',        sa.Time(),     nullable=True),
        sa.Column('work_minutes',     sa.Integer(),  server_default='0'),
        sa.Column('overtime_minutes', sa.Integer(),  server_default='0'),
        sa.Column('late_minutes',     sa.Integer(),  server_default='0'),
        sa.Column('status',           sa.String(30), server_default='on_time'),
        sa.Column('method',           sa.String(30), server_default='manual'),
        sa.Column('note',             sa.Text(),     nullable=True),
        sa.Column('is_approved',      sa.Boolean(),  server_default='0'),
        sa.Column('created_at',       sa.DateTime(timezone=True), server_default=sa.text('now()')),
        sa.Column('updated_at',       sa.DateTime(timezone=True), server_default=sa.text('now()')),
    )
    op.create_index('ix_att_tenant_emp_date', 'attendance_records', ['tenant_id', 'employee_id', 'date'])
    op.create_index('ix_att_date', 'attendance_records', ['tenant_id', 'date'])

def downgrade() -> None:
    for t in ['attendance_records','leave_requests','timetables','devices',
              'users','employee_documents','employees','positions','departments','tenants']:
        op.drop_table(t)
