"""
VigiPulse — Moteur IA de bien-être prédictif
World First : premier logiciel de pointage avec scoring burnout intégré
Auteur : VigiTime Engineering
"""
import datetime
from typing import Optional
from dataclasses import dataclass
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from app.models.attendance import AttendanceRecord, LeaveRequest
from app.models.employee import Employee


# ─────────────────────────────────────────────
# Modèle de résultat VigiPulse
# ─────────────────────────────────────────────
@dataclass
class PulseScore:
    employee_id:        str
    full_name:          str
    department:         str
    score:              int          # 0-100  (100 = excellent)
    level:              str          # green / orange / red
    risk_burnout:       int          # % risque burnout
    risk_absenteisme:   int          # % risque absence J+14
    signals:            list         # liste des signaux détectés
    recommendation:     str          # action recommandée au manager
    trend:              str          # improving / stable / degrading
    computed_at:        str


@dataclass
class TeamPulse:
    department:         str
    score_moyen:        int
    employees_total:    int
    employees_rouge:    int
    employees_orange:   int
    employees_vert:     int
    top_risque:         list         # 3 employés les plus à risque


# ─────────────────────────────────────────────
# Moteur de calcul VigiPulse
# ─────────────────────────────────────────────
class VigiPulseService:
    """
    Analyse les patterns de présence sur 30 jours
    et calcule un score de bien-être par employé.
    
    Signaux analysés :
    1. Tendance retards (aggravation sur 3 semaines)
    2. Heures supplémentaires répétées (surcharge)
    3. Micro-absences fréquentes (épuisement)
    4. Départ précipité systématique (désengagement)
    5. Dégradation du temps de travail effectif
    """

    WINDOW_DAYS = 30      # Fenêtre d'analyse
    RECENT_DAYS = 14      # Fenêtre récente pour tendance

    # Poids des signaux dans le score final
    WEIGHTS = {
        "retards_frequents":      20,
        "retards_aggravation":    15,
        "heures_sup_excessives":  20,
        "micro_absences":         20,
        "depart_anticipe":        10,
        "travail_insuffisant":    15,
    }

    async def compute_employee_pulse(
        self,
        db: AsyncSession,
        tenant_id: str,
        employee_id: str,
        employee_name: str = "",
        department: str = "",
    ) -> PulseScore:
        """Calcule le score VigiPulse pour un employé."""

        today = datetime.date.today()
        date_from = today - datetime.timedelta(days=self.WINDOW_DAYS)
        date_recent = today - datetime.timedelta(days=self.RECENT_DAYS)

        # ── Récupérer les pointages sur 30 jours ──
        result = await db.execute(
            select(AttendanceRecord).where(
                and_(
                    AttendanceRecord.tenant_id == tenant_id,
                    AttendanceRecord.employee_id == employee_id,
                    AttendanceRecord.date >= date_from,
                )
            ).order_by(AttendanceRecord.date.asc())
        )
        records = result.scalars().all()

        # ── Récupérer les congés / absences ──
        leaves_result = await db.execute(
            select(LeaveRequest).where(
                and_(
                    LeaveRequest.tenant_id == tenant_id,
                    LeaveRequest.employee_id == employee_id,
                    LeaveRequest.start_date >= date_from,
                    LeaveRequest.status == "approved",
                )
            )
        )
        leaves = leaves_result.scalars().all()

        if not records:
            return self._empty_score(employee_id, employee_name, department)

        # ── Calcul des métriques ──
        jours_travailles = len([r for r in records if r.status != "absent"])
        jours_absents    = len([r for r in records if r.status == "absent"])
        jours_retard     = len([r for r in records if r.status == "late"])
        total_retard_min = sum(r.late_minutes or 0 for r in records)
        total_sup_min    = sum(r.overtime_minutes or 0 for r in records)
        total_work_min   = sum(r.work_minutes or 0 for r in records)

        # Nombre de congés maladie (micro-absences)
        conges_maladie = len([l for l in leaves if l.leave_type in ("sick", "maladie")])

        # Données récentes (14 derniers jours) pour tendance
        records_recent = [r for r in records if r.date >= date_recent]
        retards_recent = len([r for r in records_recent if r.status == "late"])
        records_ancien  = [r for r in records if r.date < date_recent]
        retards_ancien  = len([r for r in records_ancien if r.status == "late"])

        # ── Calcul des signaux ──
        malus = 0
        signaux = []

        # Signal 1 — Retards fréquents
        taux_retard = (jours_retard / max(jours_travailles, 1)) * 100
        if taux_retard >= 40:
            malus += self.WEIGHTS["retards_frequents"]
            signaux.append({
                "code": "RETARDS_FREQUENTS",
                "label": f"Retards fréquents ({taux_retard:.0f}% des jours)",
                "severity": "high"
            })
        elif taux_retard >= 20:
            malus += self.WEIGHTS["retards_frequents"] * 0.5
            signaux.append({
                "code": "RETARDS_MODERÉS",
                "label": f"Retards modérés ({taux_retard:.0f}% des jours)",
                "severity": "medium"
            })

        # Signal 2 — Aggravation des retards (tendance)
        trend = "stable"
        if jours_travailles >= 10:
            if retards_recent > retards_ancien * 1.5 and retards_recent >= 3:
                malus += self.WEIGHTS["retards_aggravation"]
                trend = "degrading"
                signaux.append({
                    "code": "RETARDS_AGGRAVATION",
                    "label": "Aggravation des retards sur les 2 dernières semaines",
                    "severity": "high"
                })
            elif retards_recent < retards_ancien * 0.5:
                trend = "improving"

        # Signal 3 — Heures supplémentaires excessives (surcharge)
        moy_sup_par_jour = (total_sup_min / max(jours_travailles, 1))
        if moy_sup_par_jour >= 60:  # Plus d'1h sup par jour en moyenne
            malus += self.WEIGHTS["heures_sup_excessives"]
            signaux.append({
                "code": "SURCHARGE",
                "label": f"Surcharge chronique ({moy_sup_par_jour:.0f} min/j heures sup)",
                "severity": "high"
            })
        elif moy_sup_par_jour >= 30:
            malus += self.WEIGHTS["heures_sup_excessives"] * 0.5
            signaux.append({
                "code": "CHARGE_ELEVEE",
                "label": f"Charge de travail élevée ({moy_sup_par_jour:.0f} min/j heures sup)",
                "severity": "medium"
            })

        # Signal 4 — Micro-absences (congés maladie répétés)
        if conges_maladie >= 3:
            malus += self.WEIGHTS["micro_absences"]
            signaux.append({
                "code": "MICRO_ABSENCES",
                "label": f"{conges_maladie} congés maladie en 30 jours — signe d'épuisement",
                "severity": "high"
            })
        elif conges_maladie >= 2:
            malus += self.WEIGHTS["micro_absences"] * 0.5
            signaux.append({
                "code": "ABSENCES_MALADIE",
                "label": f"{conges_maladie} congés maladie en 30 jours",
                "severity": "medium"
            })

        # Signal 5 — Absences non justifiées fréquentes
        if jours_absents >= 5:
            malus += self.WEIGHTS["micro_absences"] * 0.8
            signaux.append({
                "code": "ABSENCES_FREQUENTES",
                "label": f"{jours_absents} absences non justifiées en 30 jours",
                "severity": "high"
            })

        # Signal 6 — Travail insuffisant (départ anticipé systématique)
        standard_work = 7 * 60  # 7h standard
        moy_work = total_work_min / max(jours_travailles, 1)
        if moy_work < standard_work * 0.8 and jours_travailles >= 5:
            malus += self.WEIGHTS["depart_anticipe"]
            signaux.append({
                "code": "DEPART_ANTICIPE",
                "label": f"Temps de travail moyen insuffisant ({moy_work/60:.1f}h/j — standard 7h)",
                "severity": "medium"
            })

        # ── Score final 0-100 ──
        malus = min(malus, 100)
        score = max(0, 100 - int(malus))

        # ── Niveau et recommandation ──
        if score >= 75:
            level = "green"
            recommendation = "Employé équilibré. Continuer le suivi mensuel."
        elif score >= 50:
            level = "orange"
            recommendation = "Planifier un entretien informel. Vérifier la charge de travail."
        else:
            level = "red"
            recommendation = "Intervention urgente recommandée. Entretien individuel cette semaine."

        # ── Risques prédictifs ──
        risk_burnout = max(0, min(100, int(malus * 0.9)))
        risk_absenteisme = max(0, min(100, int(
            (taux_retard * 0.3) +
            (conges_maladie * 15) +
            (jours_absents * 8)
        )))

        return PulseScore(
            employee_id=employee_id,
            full_name=employee_name,
            department=department,
            score=score,
            level=level,
            risk_burnout=risk_burnout,
            risk_absenteisme=min(risk_absenteisme, 95),
            signals=signaux,
            recommendation=recommendation,
            trend=trend,
            computed_at=datetime.datetime.now().isoformat(),
        )

    async def compute_tenant_pulse(
        self,
        db: AsyncSession,
        tenant_id: str,
    ) -> dict:
        """Calcule le score VigiPulse pour tous les employés d'un tenant."""

        # Récupérer tous les employés actifs
        emp_result = await db.execute(
            select(Employee).where(
                and_(
                    Employee.tenant_id == tenant_id,
                    Employee.is_active == True,
                )
            )
        )
        employees = emp_result.scalars().all()

        scores = []
        for emp in employees:
            dept = emp.department.name if emp.department else "Non assigné"
            pulse = await self.compute_employee_pulse(
                db=db,
                tenant_id=tenant_id,
                employee_id=emp.id,
                employee_name=f"{emp.first_name} {emp.last_name}",
                department=dept,
            )
            scores.append(pulse)

        if not scores:
            return {"employees": [], "teams": [], "global_score": 100}

        # ── Score global ──
        global_score = int(sum(s.score for s in scores) / len(scores))

        # ── Par département ──
        teams = {}
        for s in scores:
            if s.department not in teams:
                teams[s.department] = []
            teams[s.department].append(s)

        team_summaries = []
        for dept, dept_scores in teams.items():
            moy = int(sum(s.score for s in dept_scores) / len(dept_scores))
            rouges  = [s for s in dept_scores if s.level == "red"]
            oranges = [s for s in dept_scores if s.level == "orange"]
            verts   = [s for s in dept_scores if s.level == "green"]
            top_risque = sorted(dept_scores, key=lambda x: x.score)[:3]

            team_summaries.append(TeamPulse(
                department=dept,
                score_moyen=moy,
                employees_total=len(dept_scores),
                employees_rouge=len(rouges),
                employees_orange=len(oranges),
                employees_vert=len(verts),
                top_risque=[{"name": t.full_name, "score": t.score} for t in top_risque],
            ))

        return {
            "global_score": global_score,
            "total_employees": len(scores),
            "rouge": len([s for s in scores if s.level == "red"]),
            "orange": len([s for s in scores if s.level == "orange"]),
            "vert": len([s for s in scores if s.level == "green"]),
            "employees": [vars(s) for s in scores],
            "teams": [vars(t) for t in team_summaries],
            "computed_at": datetime.datetime.now().isoformat(),
        }

    def _empty_score(self, emp_id, name, dept) -> PulseScore:
        return PulseScore(
            employee_id=emp_id,
            full_name=name,
            department=dept,
            score=100,
            level="green",
            risk_burnout=0,
            risk_absenteisme=0,
            signals=[],
            recommendation="Pas assez de données — suivre sur 30 jours.",
            trend="stable",
            computed_at=datetime.datetime.now().isoformat(),
        )
