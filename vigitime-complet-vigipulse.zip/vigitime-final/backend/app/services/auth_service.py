"""Service d'authentification."""
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.user import User
from app.core.security import verify_password


class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def authenticate(self, email: str, password: str, tenant_slug: Optional[str] = None) -> Optional[User]:
        q = select(User).where(User.email == email, User.is_active == True)
        user = (await self.db.execute(q)).scalar_one_or_none()
        if not user or not verify_password(password, user.hashed_pass):
            return None
        return user

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        from uuid import UUID
        q = select(User).where(User.id == UUID(user_id))
        return (await self.db.execute(q)).scalar_one_or_none()
