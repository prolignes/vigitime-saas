"""
Service de calcul de présence — logique métier centrale
"""
import datetime
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from app.models.attendance import AttendanceRecord, Timetable, LeaveRequest
from app.models.employee import Employee

class AttendanceService:

    @staticmethod
    def calc_duration(
        check_in: datetime.time,
        check_out: datetime.time,
        break_minutes: int = 60,
        standard_hours: int = 8
    ) -> dict:
        """Calcule durée travaillée, heures sup, retard."""
        if not check_in or not check_out:
            return {"work_minutes": 0, "overtime_minutes": 0}

        in_min = check_in.hour * 60 + check_in.minute
        out_min = check_out.hour * 60 + check_out.minute

        # Gestion passage minuit
        if out_min <= in_min:
            out_min += 1440

        total = out_min - in_min
        work = max(0, total - break_minutes)
        standard = standard_hours * 60
        overtime = max(0, work - standard)

        return {
            "work_minutes": work,
            "overtime_minutes": overtime,
        }

    @staticmethod
    def calc_status(
        check_in: Optional[datetime.time],
        shift_start: Optional[datetime.time],
        tolerance: int = 15
    ) -> str:
        """Détermine le statut : on_time | late | absent."""
        if not check_in:
            return "absent"
        if not shift_start:
            return "on_time"
        in_min = check_in.hour * 60 + check_in.minute
        start_min = shift_start.hour * 60 + shift_start.minute
        if in_min > start_min + tolerance:
            return "late"
        return "on_time"

    @staticmethod
    def calc_late_minutes(
        check_in: Optional[datetime.time],
        shift_start: Optional[datetime.time]
    ) -> int:
        if not check_in or not shift_start:
            return 0
        in_min = check_in.hour * 60 + check_in.minute
        start_min = shift_start.hour * 60 + shift_start.minute
        return max(0, in_min - start_min)

    async def get_employee_stats(
        self, db: AsyncSession, tenant_id: str, employee_id: str,
        date_from: Optional[datetime.date] = None,
        date_to: Optional[datetime.date] = None
    ) -> dict:
        """Statistiques complètes pour un employé."""
        q = select(AttendanceRecord).where(
            and_(
                AttendanceRecord.tenant_id == tenant_id,
                AttendanceRecord.employee_id == employee_id
            )
        )
        if date_from:
            q = q.where(AttendanceRecord.date >= date_from)
        if date_to:
            q = q.where(AttendanceRecord.date <= date_to)

        result = await db.execute(q)
        records = result.scalars().all()

        total = len(records)
        present = sum(1 for r in records if r.status != "absent")
        late = sum(1 for r in records if r.status == "late")
        absent = sum(1 for r in records if r.status == "absent")
        work_h = sum(r.work_minutes for r in records) / 60
        overtime_h = sum(r.overtime_minutes for r in records) / 60

        return {
            "total_days": total,
            "present": present,
            "late": late,
            "absent": absent,
            "work_hours": round(work_h, 2),
            "overtime_hours": round(overtime_h, 2),
            "attendance_rate": round(present / total * 100 if total else 0, 1),
        }

    async def get_department_stats(
        self, db: AsyncSession, tenant_id: str,
        date_from: datetime.date, date_to: datetime.date
    ) -> list[dict]:
        """Statistiques par département pour les rapports."""
        from app.models.employee import Department
        result = await db.execute(
            select(Department).where(Department.tenant_id == tenant_id)
        )
        depts = result.scalars().all()
        stats = []
        for dept in depts:
            emp_result = await db.execute(
                select(Employee).where(
                    and_(Employee.tenant_id == tenant_id,
                         Employee.department_id == dept.id,
                         Employee.status == "active")
                )
            )
            employees = emp_result.scalars().all()
            if not employees:
                continue
            emp_ids = [e.id for e in employees]
            att_result = await db.execute(
                select(AttendanceRecord).where(
                    and_(
                        AttendanceRecord.tenant_id == tenant_id,
                        AttendanceRecord.employee_id.in_(emp_ids),
                        AttendanceRecord.date >= date_from,
                        AttendanceRecord.date <= date_to,
                    )
                )
            )
            records = att_result.scalars().all()
            total = len(records)
            present = sum(1 for r in records if r.status != "absent")
            stats.append({
                "department": dept.name,
                "employee_count": len(employees),
                "attendance_rate": round(present / total * 100 if total else 0, 1),
                "total_records": total,
                "present": present,
                "absent": total - present,
            })
        return stats

attendance_service = AttendanceService()
