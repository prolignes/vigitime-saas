"""Génération de rapports — données + PDF."""
from typing import Optional, List
from uuid import UUID
from datetime import date
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
import io

from app.models.attendance import AttendanceRecord, AttendanceStatus
from app.models.employee import Employee


class ReportService:
    def __init__(self, db: AsyncSession, tenant_id: UUID):
        self.db = db
        self.tenant_id = tenant_id

    async def get_summary(self, date_from: date, date_to: date, dept_id: Optional[UUID] = None) -> List[dict]:
        """Rapport récapitulatif par employé."""
        q = select(Employee).where(
            Employee.tenant_id == self.tenant_id,
            Employee.is_deleted == False,
        )
        if dept_id:
            q = q.where(Employee.department_id == dept_id)
        employees = (await self.db.execute(q)).scalars().all()

        results = []
        for emp in employees:
            att_q = select(AttendanceRecord).where(
                AttendanceRecord.employee_id == emp.id,
                AttendanceRecord.date >= date_from,
                AttendanceRecord.date <= date_to,
            )
            records = (await self.db.execute(att_q)).scalars().all()

            present  = sum(1 for r in records if r.status != AttendanceStatus.ABSENT)
            late     = sum(1 for r in records if r.status == AttendanceStatus.LATE)
            absent   = sum(1 for r in records if r.status == AttendanceStatus.ABSENT)
            work_h   = round(sum(r.duration_min or 0 for r in records) / 60, 2)
            sup_h    = round(sum(r.overtime_min or 0 for r in records) / 60, 2)
            late_min = sum(r.late_min or 0 for r in records)
            rate     = round(present / max(len(records), 1) * 100, 1)

            results.append({
                "employee_id":   str(emp.id),
                "badge_number":  emp.badge_number,
                "full_name":     f"{emp.first_name} {emp.last_name}",
                "department":    emp.department.name if emp.department else "—",
                "total_days":    len(records),
                "present":       present,
                "late":          late,
                "absent":        absent,
                "work_hours":    work_h,
                "overtime_hours":sup_h,
                "late_minutes":  late_min,
                "rate":          rate,
            })
        return sorted(results, key=lambda x: x["full_name"])

    async def get_anomalies(self) -> List[dict]:
        """Détecte les anomalies automatiquement."""
        today = date.today()
        q = select(AttendanceRecord).where(
            AttendanceRecord.tenant_id == self.tenant_id,
            AttendanceRecord.date >= date(today.year, today.month, 1),
        )
        records = (await self.db.execute(q)).scalars().all()

        anomalies = []
        for r in records:
            # Oubli de sortie
            if r.time_in and not r.time_out and r.status != AttendanceStatus.ABSENT:
                anomalies.append({
                    "type": "Oubli de sortie", "severity": "medium",
                    "employee_id": str(r.employee_id), "date": str(r.date),
                    "detail": f"Entrée {r.time_in} — aucune sortie",
                    "record_id": str(r.id),
                })
            # Retard excessif > 30 min
            if r.late_min and r.late_min > 30:
                anomalies.append({
                    "type": "Retard excessif", "severity": "high",
                    "employee_id": str(r.employee_id), "date": str(r.date),
                    "detail": f"{r.late_min} min de retard",
                    "record_id": str(r.id),
                })
            # H.Sup non approuvées > 2h
            if r.overtime_min and r.overtime_min > 120 and not r.overtime_approved:
                anomalies.append({
                    "type": "H.Sup non approuvées", "severity": "medium",
                    "employee_id": str(r.employee_id), "date": str(r.date),
                    "detail": f"{round(r.overtime_min/60, 1)}h sup non approuvées",
                    "record_id": str(r.id),
                })
        return anomalies

    async def generate_pdf_summary(self, date_from: date, date_to: date) -> bytes:
        """Génère le PDF du rapport récapitulatif avec ReportLab."""
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import mm

        summary = await self.get_summary(date_from, date_to)
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=landscape(A4), topMargin=15*mm, bottomMargin=15*mm)
        styles = getSampleStyleSheet()
        story  = []

        # Titre
        story.append(Paragraph("VigiTime — Rapport de présence récapitulatif", styles["Heading1"]))
        story.append(Paragraph(f"Période : {date_from} → {date_to}", styles["Normal"]))
        story.append(Spacer(1, 10*mm))

        # Table
        headers = ["Matricule", "Employé", "Département", "Présents", "Retards", "Absents", "H.Trav", "H.Sup", "Taux"]
        rows = [headers]
        for r in summary:
            rows.append([
                r["badge_number"], r["full_name"], r["department"],
                r["present"], r["late"], r["absent"],
                f"{r['work_hours']}h", f"{r['overtime_hours']}h", f"{r['rate']}%",
            ])

        table = Table(rows, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a3a5c")),
            ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
            ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE",   (0, 0), (-1, 0), 8),
            ("FONTSIZE",   (0, 1), (-1, -1), 8),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f7fa")]),
            ("GRID",       (0, 0), (-1, -1), 0.5, colors.HexColor("#dde1e7")),
            ("ALIGN",      (3, 0), (-1, -1), "CENTER"),
        ]))
        story.append(table)
        doc.build(story)
        return buffer.getvalue()
