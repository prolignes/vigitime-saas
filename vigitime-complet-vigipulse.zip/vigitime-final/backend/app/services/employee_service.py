"""Service métier employés — logique réutilisable indépendante des routes."""
from typing import Optional, List, Tuple
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import selectinload

from app.models.employee import Employee, EmployeeStatus
from app.models.department import Department
from app.schemas.employee import EmployeeCreate, EmployeeUpdate
from app.core.config import settings


class EmployeeService:
    def __init__(self, db: AsyncSession, tenant_id: UUID):
        self.db = db
        self.tenant_id = tenant_id

    async def get_all(
        self,
        page: int = 1,
        size: int = 50,
        search: Optional[str] = None,
        department_id: Optional[UUID] = None,
        status: Optional[str] = None,
    ) -> Tuple[List[Employee], int]:
        q = (
            select(Employee)
            .where(
                Employee.tenant_id == self.tenant_id,
                Employee.is_deleted == False,
            )
            .options(selectinload(Employee.department))
        )
        if search:
            pattern = f"%{search}%"
            q = q.where(
                or_(
                    Employee.first_name.ilike(pattern),
                    Employee.last_name.ilike(pattern),
                    Employee.badge_number.ilike(pattern),
                    Employee.email.ilike(pattern),
                )
            )
        if department_id:
            q = q.where(Employee.department_id == department_id)
        if status:
            q = q.where(Employee.status == status)

        # Compter total
        count_q = select(func.count()).select_from(q.subquery())
        total = (await self.db.execute(count_q)).scalar_one()

        # Paginer
        q = q.order_by(Employee.last_name, Employee.first_name)
        q = q.offset((page - 1) * size).limit(size)
        result = await self.db.execute(q)
        employees = result.scalars().all()

        return employees, total

    async def get_by_id(self, employee_id: UUID) -> Optional[Employee]:
        q = (
            select(Employee)
            .where(Employee.id == employee_id, Employee.tenant_id == self.tenant_id)
            .options(selectinload(Employee.department))
        )
        result = await self.db.execute(q)
        return result.scalar_one_or_none()

    async def get_by_badge(self, badge_number: str) -> Optional[Employee]:
        q = select(Employee).where(
            Employee.badge_number == badge_number,
            Employee.tenant_id == self.tenant_id,
        )
        return (await self.db.execute(q)).scalar_one_or_none()

    async def create(self, data: EmployeeCreate) -> Employee:
        # Vérifier unicité matricule
        existing = await self.get_by_badge(data.badge_number)
        if existing:
            raise ValueError(f"Matricule {data.badge_number} déjà utilisé")

        emp = Employee(
            tenant_id=self.tenant_id,
            **data.model_dump(exclude_none=True),
        )
        # Initialiser l'historique département
        if data.department_id:
            from datetime import date
            emp.dept_history = [{"dept_id": str(data.department_id), "from": str(date.today()), "to": None}]

        self.db.add(emp)
        await self.db.flush()
        await self.db.refresh(emp)
        return emp

    async def update(self, employee_id: UUID, data: EmployeeUpdate) -> Employee:
        emp = await self.get_by_id(employee_id)
        if not emp:
            raise ValueError("Employé introuvable")

        update_data = data.model_dump(exclude_none=True)

        # Gérer le transfert de département
        if "department_id" in update_data and update_data["department_id"] != emp.department_id:
            from datetime import date
            today = str(date.today())
            history = emp.dept_history or []
            if history:
                history[-1]["to"] = today
            history.append({"dept_id": str(update_data["department_id"]), "from": today, "to": None})
            emp.dept_history = history

        for key, value in update_data.items():
            setattr(emp, key, value)

        await self.db.flush()
        await self.db.refresh(emp)
        return emp

    async def soft_delete(self, employee_id: UUID) -> bool:
        emp = await self.get_by_id(employee_id)
        if not emp:
            return False
        from datetime import datetime
        emp.is_deleted = True
        emp.deleted_at = datetime.utcnow()
        emp.status = EmployeeStatus.TERMINATED
        await self.db.flush()
        return True

    async def resign(self, employee_id: UUID, date, reason: str) -> Employee:
        emp = await self.get_by_id(employee_id)
        if not emp:
            raise ValueError("Employé introuvable")
        emp.resignation_date = date
        emp.resignation_reason = reason
        emp.status = EmployeeStatus.RESIGNED
        if emp.dept_history:
            emp.dept_history[-1]["to"] = str(date)
        await self.db.flush()
        return emp

    async def reinstate(self, employee_id: UUID) -> Employee:
        emp = await self.get_by_id(employee_id)
        if not emp:
            raise ValueError("Employé introuvable")
        from datetime import date
        emp.resignation_date = None
        emp.resignation_reason = None
        emp.status = EmployeeStatus.ACTIVE
        history = emp.dept_history or []
        history.append({"dept_id": str(emp.department_id) if emp.department_id else None, "from": str(date.today()), "to": None})
        emp.dept_history = history
        await self.db.flush()
        return emp
