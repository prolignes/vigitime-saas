"""Session SQLAlchemy async + multi-tenant."""
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import text

from app.core.config import settings

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
)

AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def set_tenant_schema(db: AsyncSession, tenant_slug: str):
    """Active le schéma PostgreSQL pour le tenant courant (isolation totale)."""
    await db.execute(text(f"SET search_path TO {tenant_slug}, public"))


async def create_tenant_schema(tenant_slug: str):
    """Crée un nouveau schéma PostgreSQL pour un tenant."""
    async with engine.begin() as conn:
        await conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {tenant_slug}"))
        # Créer les tables dans ce schéma
        await conn.execute(text(f"SET search_path TO {tenant_slug}"))
        await conn.run_sync(Base.metadata.create_all)
        await conn.execute(text("SET search_path TO public"))
