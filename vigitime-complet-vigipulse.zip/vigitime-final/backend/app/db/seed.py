"""
Script de seed — crée les données initiales :
- 1 tenant de démonstration
- 3 utilisateurs (admin, rh, superviseur)
- 5 départements
- 8 employés réels
- 1 timetable standard
- Quelques pointages récents
"""
import asyncio
import datetime
import uuid
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from app.core.config import settings
from app.core.security import hash_password
from app.models import Tenant, User, Department, Position, Employee, Timetable, AttendanceRecord

engine = create_async_engine(settings.DATABASE_URL, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

def uid(): return str(uuid.uuid4())
def today(): return datetime.date.today()
def yesterday(): return today() - datetime.timedelta(days=1)
def t(h, m=0): return datetime.time(h, m)

async def seed():
    async with AsyncSessionLocal() as db:

        # ── Tenant ──
        tenant = Tenant(
            id=uid(), name="Entreprise Algérienne SARL",
            slug="demo-dz", email="contact@entreprise.dz",
            phone="+213 21 00 00 00", timezone="Africa/Algiers",
            locale="fr", currency="DZD", weekend_days="5,6",
            plan="pro", is_active=True, max_employees=200
        )
        db.add(tenant)
        await db.flush()
        tid = tenant.id

        # ── Départements ──
        depts = {}
        for code, name in [("IT","Informatique"),("RH","Ressources Humaines"),
                            ("FIN","Finance"),("PROD","Production"),("MKT","Marketing")]:
            d = Department(id=uid(), tenant_id=tid, code=code, name=name, is_active=True)
            db.add(d)
            depts[code] = d
        await db.flush()

        # ── Positions ──
        positions = {}
        for title, dept_code, rate in [
            ("Développeur Senior",    "IT",   450),
            ("Responsable RH",        "RH",   400),
            ("Comptable",             "FIN",  380),
            ("Architecte Cloud",      "IT",   500),
            ("Copywriter",            "MKT",  320),
            ("Assistante RH",         "RH",   310),
            ("Chef de Production",    "PROD", 420),
            ("Analyste Financier",    "FIN",  390),
        ]:
            p = Position(id=uid(), tenant_id=tid, title=title,
                         department_id=depts[dept_code].id, hourly_rate=rate)
            db.add(p)
            positions[title] = p
        await db.flush()

        # ── Utilisateurs système ──
        for email, name, role, pwd in [
            ("admin@vigitime.dz",  "Admin Système",   "admin",      "admin123"),
            ("rh@vigitime.dz",     "Responsable RH",  "rh",         "rh123"),
            ("sup@vigitime.dz",    "Superviseur",     "supervisor", "sup123"),
        ]:
            u = User(id=uid(), tenant_id=tid, email=email,
                     hashed_password=hash_password(pwd),
                     full_name=name, role=role, is_active=True, is_verified=True)
            db.add(u)

        # ── Employés ──
        emps_data = [
            ("EMP-001","Jean",    "Dupont",   "M","IT",  "Développeur Senior",   "+213 55 01 01 01","j.dupont@ent.dz",  "A1B2C3D4", "1988-04-12"),
            ("EMP-002","Marie",   "Curie",    "F","RH",  "Responsable RH",       "+213 55 02 02 02","m.curie@ent.dz",   "E5F6G7H8", "1985-11-07"),
            ("EMP-003","Paul",    "Verlaine", "M","FIN", "Comptable",            "+213 55 03 03 03","p.verlaine@ent.dz","I9J0K1L2", "1990-02-22"),
            ("EMP-004","Sophie",  "Germain",  "F","IT",  "Architecte Cloud",     "+213 55 04 04 04","s.germain@ent.dz", "M3N4O5P6", "1992-07-30"),
            ("EMP-005","Albert",  "Camus",    "M","MKT", "Copywriter",           "+213 55 05 05 05","a.camus@ent.dz",   "",         "1987-05-14"),
            ("EMP-006","Leila",   "Hadid",    "F","RH",  "Assistante RH",        "+213 55 06 06 06","l.hadid@ent.dz",   "Q7R8S9T0", "1994-09-03"),
            ("EMP-007","Karim",   "Benzema",  "M","PROD","Chef de Production",   "+213 55 07 07 07","k.benzema@ent.dz", "U1V2W3X4", "1986-12-19"),
            ("EMP-008","Nadia",   "Rahman",   "F","FIN", "Analyste Financier",   "+213 55 08 08 08","n.rahman@ent.dz",  "Y5Z6A7B8", "1991-03-25"),
        ]
        emps = {}
        for mat,fn,ln,gender,dept_code,pos_title,phone,email,nfc,bdate in emps_data:
            e = Employee(
                id=uid(), tenant_id=tid, matricule=mat,
                first_name=fn, last_name=ln, gender=gender,
                birth_date=datetime.date.fromisoformat(bdate),
                nationality="Algérienne",
                email=email, phone=phone,
                department_id=depts[dept_code].id,
                position_id=positions[pos_title].id,
                hire_date=datetime.date(2018,1,1),
                hourly_rate=positions[pos_title].hourly_rate,
                badge_nfc=nfc or None,
                status="active" if mat != "EMP-005" else "inactive",
            )
            db.add(e)
            emps[mat] = e
        await db.flush()

        # ── Créneau horaire ──
        tt = Timetable(
            id=uid(), tenant_id=tid, name="Shift Standard",
            start_time=t(9,0), end_time=t(17,0),
            break_minutes=60, late_tolerance=15, early_tolerance=15, is_active=True
        )
        db.add(tt)
        await db.flush()

        # ── Pointages des 7 derniers jours ──
        punch_data = [
            ("EMP-001", t(8,52), t(17,45), "on_time"),
            ("EMP-002", t(9,18), t(17,30), "late"),
            ("EMP-003", t(9,45), t(17,0),  "late"),
            ("EMP-004", t(8,30), t(18,10), "on_time"),
            ("EMP-006", t(9,2),  t(16,55), "on_time"),
            ("EMP-007", t(7,5),  t(15,10), "on_time"),
            ("EMP-008", t(9,0),  t(18,30), "on_time"),
        ]
        for days_ago in range(0, 7):
            date = today() - datetime.timedelta(days=days_ago)
            if date.weekday() in (4, 5):  # skip Ven/Sam
                continue
            for mat, check_in, check_out, status in punch_data:
                if mat not in emps:
                    continue
                work = max(0, (check_out.hour*60+check_out.minute) - (check_in.hour*60+check_in.minute) - 60)
                std = 8 * 60
                overtime = max(0, work - std)
                late = max(0, (check_in.hour*60+check_in.minute) - (t(9,0).hour*60+t(9,0).minute))
                rec = AttendanceRecord(
                    id=uid(), tenant_id=tid,
                    employee_id=emps[mat].id,
                    timetable_id=tt.id,
                    date=date,
                    check_in=check_in, check_out=check_out,
                    work_minutes=work, overtime_minutes=overtime,
                    late_minutes=late, status=status,
                    method="fingerprint" if days_ago % 2 == 0 else "face_id",
                    is_approved=True,
                )
                db.add(rec)

        # EMP-005 absent toute la semaine
        for days_ago in range(0, 5):
            date = today() - datetime.timedelta(days=days_ago)
            if date.weekday() in (4, 5):
                continue
            rec = AttendanceRecord(
                id=uid(), tenant_id=tid,
                employee_id=emps["EMP-005"].id,
                date=date, status="absent",
                method="—", work_minutes=0,
            )
            db.add(rec)

        await db.commit()
        print(f"✅ Seed terminé — Tenant: {tenant.name} ({tid})")
        print(f"   {len(emps)} employés | {len(depts)} depts | timetable créé")
        print(f"\n   Accès démo:")
        print(f"   admin@vigitime.dz  / admin123  (Super Admin)")
        print(f"   rh@vigitime.dz     / rh123     (Responsable RH)")
        print(f"   sup@vigitime.dz    / sup123    (Superviseur)")

if __name__ == "__main__":
    asyncio.run(seed())
