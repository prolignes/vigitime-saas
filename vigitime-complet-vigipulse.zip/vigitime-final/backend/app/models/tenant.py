from __future__ import annotations
from typing import TYPE_CHECKING, List
from sqlalchemy import String, Boolean, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import UUIDMixin, TimestampMixin
from app.core.database import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.employee import Employee, Department
    from app.models.device import Device

class Tenant(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "tenants"

    name:         Mapped[str]  = mapped_column(String(200), nullable=False)
    slug:         Mapped[str]  = mapped_column(String(100), unique=True, nullable=False)
    address:      Mapped[str]  = mapped_column(String(500), nullable=True)
    phone:        Mapped[str]  = mapped_column(String(30),  nullable=True)
    email:        Mapped[str]  = mapped_column(String(200), nullable=True)
    logo_url:     Mapped[str]  = mapped_column(String(500), nullable=True)
    timezone:     Mapped[str]  = mapped_column(String(50),  default="Africa/Algiers")
    locale:       Mapped[str]  = mapped_column(String(10),  default="fr")
    currency:     Mapped[str]  = mapped_column(String(10),  default="DZD")
    weekend_days: Mapped[str]  = mapped_column(String(20),  default="5,6")
    plan:         Mapped[str]  = mapped_column(String(50),  default="free")
    is_active:    Mapped[bool] = mapped_column(Boolean,     default=True)
    max_employees:Mapped[int]  = mapped_column(Integer,     default=50)

    users:       Mapped[List["User"]]       = relationship("User",       back_populates="tenant", cascade="all, delete-orphan")
    employees:   Mapped[List["Employee"]]   = relationship("Employee",   back_populates="tenant", cascade="all, delete-orphan")
    departments: Mapped[List["Department"]] = relationship("Department", back_populates="tenant", cascade="all, delete-orphan")
    devices:     Mapped[List["Device"]]     = relationship("Device",     back_populates="tenant", cascade="all, delete-orphan")
