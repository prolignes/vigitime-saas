from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from app.models.base import Base, UUIDMixin, TimestampMixin


class Department(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "departments"

    tenant_id   = Column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False)
    parent_id   = Column(UUID(as_uuid=True), ForeignKey("departments.id"), nullable=True)
    code        = Column(String(20), nullable=False)
    name        = Column(String(200), nullable=False)
    manager_id  = Column(UUID(as_uuid=True), ForeignKey("employees.id"), nullable=True)

    parent      = relationship("Department", remote_side="Department.id")
    manager     = relationship("Employee", foreign_keys=[manager_id])
    employees   = relationship("Employee", foreign_keys="Employee.department_id", back_populates="department")
