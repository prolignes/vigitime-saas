from __future__ import annotations
from typing import TYPE_CHECKING, Optional
from sqlalchemy import String, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import UUIDMixin, TimestampMixin
from app.core.database import Base

if TYPE_CHECKING:
    from app.models.tenant import Tenant
    from app.models.employee import Employee

class User(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "users"

    tenant_id:       Mapped[str]  = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    email:           Mapped[str]  = mapped_column(String(200), nullable=False)
    hashed_password: Mapped[str]  = mapped_column(String(200), nullable=False)
    full_name:       Mapped[str]  = mapped_column(String(200), nullable=False)
    role:            Mapped[str]  = mapped_column(String(50),  default="viewer")
    avatar_url:      Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    is_active:       Mapped[bool] = mapped_column(Boolean, default=True)
    is_verified:     Mapped[bool] = mapped_column(Boolean, default=False)
    last_login_at:   Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    employee_id:     Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("employees.id", ondelete="SET NULL"), nullable=True)

    tenant:   Mapped["Tenant"]   = relationship("Tenant",   back_populates="users")
    employee: Mapped[Optional["Employee"]] = relationship("Employee", foreign_keys=[employee_id])
