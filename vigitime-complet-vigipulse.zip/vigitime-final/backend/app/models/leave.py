"""Demandes de congé."""
from sqlalchemy import Column, String, Integer, Date, Text, ForeignKey, Enum as SAEnum, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import enum
from app.models.base import Base, UUIDMixin, TimestampMixin


class LeaveType(str, enum.Enum):
    VACATION  = "vacation"
    SICK      = "sick"
    PERSONAL  = "personal"
    MATERNITY = "maternity"
    UNPAID    = "unpaid"
    OTHER     = "other"


class LeaveStatus(str, enum.Enum):
    PENDING   = "pending"
    APPROVED  = "approved"
    REJECTED  = "rejected"
    CANCELLED = "cancelled"


class LeaveRequest(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "leave_requests"

    tenant_id   = Column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False)
    employee_id = Column(UUID(as_uuid=True), ForeignKey("employees.id"), nullable=False)
    approved_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    leave_type  = Column(SAEnum(LeaveType), nullable=False)
    date_from   = Column(Date, nullable=False)
    date_to     = Column(Date, nullable=False)
    days_count  = Column(Integer, nullable=False)
    reason      = Column(Text, nullable=True)
    status      = Column(SAEnum(LeaveStatus), default=LeaveStatus.PENDING)
    is_paid     = Column(Boolean, default=True)
    notes       = Column(Text, nullable=True)

    employee    = relationship("Employee", back_populates="leaves")
    approver    = relationship("User", foreign_keys=[approved_by])
