from __future__ import annotations
from typing import TYPE_CHECKING, Optional
from sqlalchemy import String, Boolean, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import UUIDMixin, TimestampMixin
from app.core.database import Base

if TYPE_CHECKING:
    from app.models.tenant import Tenant

class Device(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "devices"

    tenant_id:     Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    name:          Mapped[str]           = mapped_column(String(100), nullable=False)
    serial_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    model:         Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    brand:         Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    firmware:      Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    ip_address:    Mapped[str]           = mapped_column(String(50),  nullable=False)
    port:          Mapped[int]           = mapped_column(Integer,     default=4370)
    comm_key:      Mapped[int]           = mapped_column(Integer,     default=0)
    protocol:      Mapped[str]           = mapped_column(String(20),  default="zkteco")
    location:      Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    area:          Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    status:        Mapped[str]           = mapped_column(String(20),  default="offline")
    last_sync_at:  Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    total_records: Mapped[int]           = mapped_column(Integer,     default=0)
    is_active:     Mapped[bool]          = mapped_column(Boolean,     default=True)

    tenant: Mapped["Tenant"] = relationship("Tenant", back_populates="devices")
