from __future__ import annotations
from typing import TYPE_CHECKING, Optional, List
import datetime
from sqlalchemy import String, Boolean, Integer, Float, ForeignKey, Text, Date, Time
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import UUIDMixin, TimestampMixin
from app.core.database import Base

if TYPE_CHECKING:
    from app.models.employee import Employee
    from app.models.device import Device

class Timetable(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "timetables"

    tenant_id:       Mapped[str]  = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    name:            Mapped[str]  = mapped_column(String(100), nullable=False)
    start_time:      Mapped[datetime.time] = mapped_column(Time, nullable=False)
    end_time:        Mapped[datetime.time] = mapped_column(Time, nullable=False)
    break_minutes:   Mapped[int]  = mapped_column(Integer, default=60)
    late_tolerance:  Mapped[int]  = mapped_column(Integer, default=15)
    early_tolerance: Mapped[int]  = mapped_column(Integer, default=15)
    is_active:       Mapped[bool] = mapped_column(Boolean, default=True)

class AttendanceRecord(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "attendance_records"

    tenant_id:        Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id",   ondelete="CASCADE"), nullable=False, index=True)
    employee_id:      Mapped[str]           = mapped_column(String(36), ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    timetable_id:     Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("timetables.id",ondelete="SET NULL"), nullable=True)
    device_id:        Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("devices.id",   ondelete="SET NULL"), nullable=True)
    leave_id:         Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("leave_requests.id", ondelete="SET NULL"), nullable=True)

    date:             Mapped[datetime.date] = mapped_column(Date, nullable=False, index=True)
    check_in:         Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)
    check_out:        Mapped[Optional[datetime.time]] = mapped_column(Time, nullable=True)
    work_minutes:     Mapped[int]  = mapped_column(Integer, default=0)
    overtime_minutes: Mapped[int]  = mapped_column(Integer, default=0)
    late_minutes:     Mapped[int]  = mapped_column(Integer, default=0)
    status:           Mapped[str]  = mapped_column(String(30), default="on_time", index=True)
    method:           Mapped[str]  = mapped_column(String(30), default="manual")
    note:             Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_approved:      Mapped[bool] = mapped_column(Boolean, default=False)

    employee:  Mapped["Employee"]          = relationship("Employee", back_populates="attendance_records")
    device:    Mapped[Optional["Device"]]  = relationship("Device")
    timetable: Mapped[Optional["Timetable"]] = relationship("Timetable")

class LeaveRequest(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "leave_requests"

    tenant_id:        Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id",   ondelete="CASCADE"), nullable=False, index=True)
    employee_id:      Mapped[str]           = mapped_column(String(36), ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    approved_by:      Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("users.id",     ondelete="SET NULL"), nullable=True)

    leave_type:       Mapped[str]           = mapped_column(String(30), nullable=False)
    start_date:       Mapped[datetime.date] = mapped_column(Date, nullable=False)
    end_date:         Mapped[datetime.date] = mapped_column(Date, nullable=False)
    working_days:     Mapped[int]           = mapped_column(Integer, default=0)
    reason:           Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status:           Mapped[str]           = mapped_column(String(20), default="pending", index=True)
    approved_at:      Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    rejection_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    employee: Mapped["Employee"] = relationship("Employee", back_populates="leaves")
