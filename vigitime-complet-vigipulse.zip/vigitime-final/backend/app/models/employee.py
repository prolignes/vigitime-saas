from __future__ import annotations
from typing import TYPE_CHECKING, Optional, List
import datetime
from sqlalchemy import String, Boolean, Integer, Float, ForeignKey, Text, Date
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import UUIDMixin, TimestampMixin
from app.core.database import Base

if TYPE_CHECKING:
    from app.models.tenant import Tenant
    from app.models.attendance import AttendanceRecord, LeaveRequest

class Department(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "departments"

    tenant_id:  Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    code:       Mapped[str]           = mapped_column(String(20),  nullable=False)
    name:       Mapped[str]           = mapped_column(String(200), nullable=False)
    manager_id: Mapped[Optional[str]] = mapped_column(String(36),  ForeignKey("employees.id", ondelete="SET NULL"), nullable=True)
    is_active:  Mapped[bool]          = mapped_column(Boolean, default=True)

    tenant:    Mapped["Tenant"]       = relationship("Tenant", back_populates="departments")
    employees: Mapped[List["Employee"]] = relationship("Employee", back_populates="department", foreign_keys="Employee.department_id")

class Position(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "positions"

    tenant_id:     Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    title:         Mapped[str]           = mapped_column(String(200), nullable=False)
    department_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    hourly_rate:   Mapped[float]         = mapped_column(Float, default=312.0)

class Employee(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "employees"

    tenant_id:       Mapped[str]           = mapped_column(String(36), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    matricule:       Mapped[str]           = mapped_column(String(50),  nullable=False)
    first_name:      Mapped[str]           = mapped_column(String(100), nullable=False)
    last_name:       Mapped[str]           = mapped_column(String(100), nullable=False)
    gender:          Mapped[Optional[str]] = mapped_column(String(10),  nullable=True)
    birth_date:      Mapped[Optional[datetime.date]] = mapped_column(Date, nullable=True)
    nationality:     Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    national_id:     Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    social_security: Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    email:           Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    phone:           Mapped[Optional[str]] = mapped_column(String(30),  nullable=True)
    address:         Mapped[Optional[str]] = mapped_column(Text,        nullable=True)
    department_id:   Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    position_id:     Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("positions.id",  ondelete="SET NULL"), nullable=True)
    hire_date:       Mapped[Optional[datetime.date]] = mapped_column(Date, nullable=True)
    hourly_rate:     Mapped[float]         = mapped_column(Float, default=312.0)
    badge_nfc:       Mapped[Optional[str]] = mapped_column(String(50),  nullable=True)
    pin_code:        Mapped[Optional[str]] = mapped_column(String(10),  nullable=True)
    zkteco_uid:      Mapped[Optional[int]] = mapped_column(Integer,     nullable=True)
    status:          Mapped[str]           = mapped_column(String(20),  default="active", index=True)
    photo_url:       Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    tenant:     Mapped["Tenant"]              = relationship("Tenant",     back_populates="employees")
    department: Mapped[Optional["Department"]]= relationship("Department", back_populates="employees", foreign_keys=[department_id])
    position:   Mapped[Optional["Position"]]  = relationship("Position",   foreign_keys=[position_id])
    attendance_records: Mapped[List["AttendanceRecord"]] = relationship("AttendanceRecord", back_populates="employee", cascade="all, delete-orphan")
    leaves:    Mapped[List["LeaveRequest"]]   = relationship("LeaveRequest", back_populates="employee", cascade="all, delete-orphan")
    documents: Mapped[List["EmployeeDocument"]] = relationship("EmployeeDocument", back_populates="employee", cascade="all, delete-orphan")

class EmployeeDocument(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "employee_documents"

    tenant_id:   Mapped[str] = mapped_column(String(36), ForeignKey("tenants.id",   ondelete="CASCADE"), nullable=False)
    employee_id: Mapped[str] = mapped_column(String(36), ForeignKey("employees.id", ondelete="CASCADE"), nullable=False, index=True)
    doc_type:    Mapped[str] = mapped_column(String(50),  nullable=False)
    name:        Mapped[str] = mapped_column(String(200), nullable=False)
    file_url:    Mapped[str] = mapped_column(String(500), nullable=False)
    file_size:   Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    employee: Mapped["Employee"] = relationship("Employee", back_populates="documents")
