from pydantic import BaseModel, EmailStr, Field
from typing import Optional
import datetime

class EmployeeCreate(BaseModel):
    matricule: str = Field(min_length=1, max_length=50)
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    gender: Optional[str] = None
    birth_date: Optional[datetime.date] = None
    nationality: Optional[str] = None
    national_id: Optional[str] = None
    social_security: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    department_id: Optional[str] = None
    position_id: Optional[str] = None
    hire_date: Optional[datetime.date] = None
    hourly_rate: float = 312.0
    badge_nfc: Optional[str] = None
    status: str = "active"

class EmployeeUpdate(EmployeeCreate):
    matricule: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None

class EmployeeOut(BaseModel):
    id: str
    tenant_id: str
    matricule: str
    first_name: str
    last_name: str
    gender: Optional[str] = None
    birth_date: Optional[datetime.date] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    department_id: Optional[str] = None
    position_id: Optional[str] = None
    hire_date: Optional[datetime.date] = None
    hourly_rate: float
    badge_nfc: Optional[str] = None
    status: str
    photo_url: Optional[str] = None
    created_at: datetime.datetime
    updated_at: datetime.datetime

    class Config:
        from_attributes = True

class EmployeeListResponse(BaseModel):
    items: list[EmployeeOut]
    total: int
    page: int
    page_size: int
    pages: int
