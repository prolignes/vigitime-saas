from pydantic import BaseModel, Field
from typing import Optional
import datetime

class AttendanceCreate(BaseModel):
    employee_id: str
    date: datetime.date
    check_in: Optional[datetime.time] = None
    check_out: Optional[datetime.time] = None
    status: str = "on_time"
    method: str = "manual"
    note: Optional[str] = None

class AttendanceOut(BaseModel):
    id: str
    employee_id: str
    date: datetime.date
    check_in: Optional[datetime.time] = None
    check_out: Optional[datetime.time] = None
    work_minutes: int
    overtime_minutes: int
    late_minutes: int
    status: str
    method: str
    is_approved: bool
    note: Optional[str] = None

    class Config:
        from_attributes = True

class LeaveCreate(BaseModel):
    employee_id: str
    leave_type: str
    start_date: datetime.date
    end_date: datetime.date
    reason: Optional[str] = None

class LeaveOut(BaseModel):
    id: str
    employee_id: str
    leave_type: str
    start_date: datetime.date
    end_date: datetime.date
    working_days: int
    reason: Optional[str] = None
    status: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True
