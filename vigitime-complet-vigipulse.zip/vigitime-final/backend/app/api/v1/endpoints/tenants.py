"""Gestion des tenants (super admin uniquement)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.db.session import get_db, create_tenant_schema
from app.core.security import require_roles
from app.models.tenant import Tenant
from app.models.user import User, UserRole
from app.core.security import hash_password
import uuid

router = APIRouter()
require_superadmin = require_roles("super_admin")


@router.post("/create", dependencies=[require_superadmin])
async def create_tenant(body: dict, db: AsyncSession = Depends(get_db)):
    """Crée un nouveau tenant + admin + schéma PostgreSQL."""
    slug = body.get("slug", "").lower().replace(" ", "_")
    if not slug:
        raise HTTPException(400, "Slug requis")

    # Vérifier unicité
    existing = (await db.execute(select(Tenant).where(Tenant.slug == slug))).scalar_one_or_none()
    if existing:
        raise HTTPException(409, f"Tenant '{slug}' déjà existant")

    # Créer le tenant
    tenant = Tenant(
        name=body.get("name", slug),
        slug=slug,
        plan=body.get("plan", "starter"),
        country=body.get("country", "DZ"),
        timezone=body.get("timezone", "Africa/Algiers"),
    )
    db.add(tenant)
    await db.flush()

    # Créer l'admin du tenant
    admin = User(
        tenant_id=tenant.id,
        email=body.get("admin_email"),
        hashed_pass=hash_password(body.get("admin_password", "changeme123")),
        full_name=body.get("admin_name", "Admin"),
        role=UserRole.ADMIN,
        is_active=True,
        is_verified=True,
    )
    db.add(admin)
    await db.flush()

    # Créer le schéma PostgreSQL isolé
    await create_tenant_schema(slug)

    return {
        "tenant_id": str(tenant.id),
        "slug": slug,
        "admin_id": str(admin.id),
        "message": f"Tenant '{slug}' créé avec succès",
    }
