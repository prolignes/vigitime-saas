from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, func
from typing import Optional
import uuid, os, shutil
from app.core.database import get_db
from app.core.deps import get_current_tenant_id, get_current_user
from app.core.config import settings
from app.models.employee import Employee, Department, Position
from app.schemas.employee import EmployeeCreate, EmployeeUpdate, EmployeeOut, EmployeeListResponse
from app.models.user import User

router = APIRouter(prefix="/employees", tags=["Employees"])

@router.get("", response_model=EmployeeListResponse)
async def list_employees(
    page:          int = Query(1, ge=1),
    page_size:     int = Query(15, ge=1, le=100),
    search:        Optional[str] = None,
    department_id: Optional[str] = None,
    status:        Optional[str] = None,
    db:            AsyncSession = Depends(get_db),
    tenant_id:     str = Depends(get_current_tenant_id),
):
    q = select(Employee).where(Employee.tenant_id == tenant_id)
    if search:
        q = q.where(or_(
            Employee.first_name.ilike(f"%{search}%"),
            Employee.last_name.ilike(f"%{search}%"),
            Employee.matricule.ilike(f"%{search}%"),
            Employee.email.ilike(f"%{search}%"),
        ))
    if department_id:
        q = q.where(Employee.department_id == department_id)
    if status:
        q = q.where(Employee.status == status)

    total_q = select(func.count()).select_from(q.subquery())
    total = (await db.execute(total_q)).scalar() or 0

    q = q.order_by(Employee.last_name).offset((page - 1) * page_size).limit(page_size)
    items = (await db.execute(q)).scalars().all()

    return EmployeeListResponse(
        items=[EmployeeOut.model_validate(e) for e in items],
        total=total, page=page, page_size=page_size,
        pages=max(1, -(-total // page_size))
    )

@router.post("", response_model=EmployeeOut, status_code=201)
async def create_employee(
    data:      EmployeeCreate,
    db:        AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    existing = (await db.execute(
        select(Employee).where(and_(
            Employee.tenant_id == tenant_id,
            Employee.matricule == data.matricule
        ))
    )).scalar_one_or_none()
    if existing:
        raise HTTPException(400, f"Matricule {data.matricule} déjà utilisé")

    emp = Employee(id=str(uuid.uuid4()), tenant_id=tenant_id, **data.model_dump())
    db.add(emp)
    await db.flush()
    return EmployeeOut.model_validate(emp)

@router.get("/{emp_id}", response_model=EmployeeOut)
async def get_employee(
    emp_id: str, db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    emp = (await db.execute(
        select(Employee).where(and_(Employee.id == emp_id, Employee.tenant_id == tenant_id))
    )).scalar_one_or_none()
    if not emp:
        raise HTTPException(404, "Employé introuvable")
    return EmployeeOut.model_validate(emp)

@router.patch("/{emp_id}", response_model=EmployeeOut)
async def update_employee(
    emp_id: str, data: EmployeeUpdate,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    emp = (await db.execute(
        select(Employee).where(and_(Employee.id == emp_id, Employee.tenant_id == tenant_id))
    )).scalar_one_or_none()
    if not emp:
        raise HTTPException(404, "Employé introuvable")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(emp, k, v)
    return EmployeeOut.model_validate(emp)

@router.delete("/{emp_id}", status_code=204)
async def delete_employee(
    emp_id: str, db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    emp = (await db.execute(
        select(Employee).where(and_(Employee.id == emp_id, Employee.tenant_id == tenant_id))
    )).scalar_one_or_none()
    if not emp:
        raise HTTPException(404, "Employé introuvable")
    await db.delete(emp)

@router.post("/{emp_id}/photo")
async def upload_photo(
    emp_id: str, file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(400, "Image requise")
    ext = (file.filename or "photo.jpg").split(".")[-1].lower()
    rel_path = f"photos/{tenant_id}/{emp_id}.{ext}"
    full_path = os.path.join(settings.UPLOAD_DIR, rel_path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    emp = (await db.execute(
        select(Employee).where(and_(Employee.id == emp_id, Employee.tenant_id == tenant_id))
    )).scalar_one_or_none()
    if emp:
        emp.photo_url = f"/uploads/{rel_path}"
    return {"photo_url": f"/uploads/{rel_path}"}

@router.get("/{emp_id}/stats")
async def get_employee_stats(
    emp_id: str, db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    from app.services.attendance_service import attendance_service
    return await attendance_service.get_employee_stats(db, tenant_id, emp_id)

@router.get("/departments/list")
async def list_departments(
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_current_tenant_id),
):
    result = await db.execute(
        select(Department).where(Department.tenant_id == tenant_id, Department.is_active == True)
        .order_by(Department.name)
    )
    return [{"id": d.id, "code": d.code, "name": d.name} for d in result.scalars().all()]
