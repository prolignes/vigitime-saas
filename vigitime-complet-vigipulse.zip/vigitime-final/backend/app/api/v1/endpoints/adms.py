"""
Endpoint ADMS Cloud — les terminaux ZKTeco poussent les pointages directement ici.
Aucun proxy local requis.
"""
from fastapi import APIRouter, Request, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.core.database import get_db
from app.models.device import Device
from app.models.employee import Employee
from app.models.attendance import AttendanceRecord, Timetable
from app.services.attendance_service import attendance_service
import datetime, uuid

router = APIRouter(prefix="/adms", tags=["ADMS Push"])

@router.post("/push")
async def adms_push(request: Request, db: AsyncSession = Depends(get_db)):
    """
    Endpoint ADMS ZKTeco Push Protocol.
    Le terminal envoie des données form-encoded :
      SN=<serial>
      table=<attendance_log>
      Stamp=<last_sync_timestamp>
    """
    try:
        body = await request.form()
    except Exception:
        body = {}

    sn      = body.get("SN", "")
    records = body.get("table", "")
    
    if not sn:
        return {"ret": "failed", "reason": "SN manquant"}

    # Trouver le terminal par numéro de série
    dev_result = await db.execute(
        select(Device).where(Device.serial_number == sn, Device.is_active == True)
    )
    device = dev_result.scalar_one_or_none()
    if not device:
        return {"ret": "failed", "reason": f"Terminal {sn} non enregistré"}

    tenant_id = device.tenant_id
    imported = 0

    # Timetable par défaut
    tt_result = await db.execute(
        select(Timetable).where(Timetable.tenant_id == tenant_id, Timetable.is_active == True).limit(1)
    )
    timetable = tt_result.scalar_one_or_none()

    # Parser les lignes de pointage
    # Format ZKTeco : PIN\tDatetime\tStatus\tVerify\tWorkCode\tReserved
    for line in (records or "").strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue

        pin    = parts[0].strip()
        dt_str = parts[1].strip()
        status_code = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
        # 0=Check-In, 1=Check-Out, 2=Break-Out, 3=Break-In, 4=OT-In, 5=OT-Out

        try:
            dt = datetime.datetime.fromisoformat(dt_str.replace(" ", "T"))
        except ValueError:
            continue

        # Trouver l'employé par PIN (matricule ou zkteco_uid)
        emp_result = await db.execute(
            select(Employee).where(
                and_(Employee.tenant_id == tenant_id,
                     Employee.pin_code == pin)
            )
        )
        emp = emp_result.scalar_one_or_none()
        if not emp:
            continue

        # Chercher un enregistrement existant pour ce jour
        date = dt.date()
        existing = (await db.execute(
            select(AttendanceRecord).where(
                and_(AttendanceRecord.tenant_id == tenant_id,
                     AttendanceRecord.employee_id == emp.id,
                     AttendanceRecord.date == date)
            )
        )).scalar_one_or_none()

        time_val = dt.time()

        if status_code == 0:  # Check-In
            if existing:
                if not existing.check_in:
                    existing.check_in = time_val
            else:
                rec = AttendanceRecord(
                    id=str(uuid.uuid4()), tenant_id=tenant_id,
                    employee_id=emp.id, device_id=device.id,
                    timetable_id=timetable.id if timetable else None,
                    date=date, check_in=time_val,
                    status=attendance_service.calc_status(time_val, timetable.start_time if timetable else None),
                    late_minutes=attendance_service.calc_late_minutes(time_val, timetable.start_time if timetable else None),
                    method="fingerprint",
                )
                db.add(rec)

        elif status_code == 1:  # Check-Out
            if existing and existing.check_in:
                existing.check_out = time_val
                durations = attendance_service.calc_duration(existing.check_in, time_val,
                            timetable.break_minutes if timetable else 60)
                existing.work_minutes     = durations["work_minutes"]
                existing.overtime_minutes = durations["overtime_minutes"]

        imported += 1

    # Mettre à jour le terminal
    device.last_sync_at  = datetime.datetime.now().isoformat()
    device.total_records += imported
    device.status         = "online"

    await db.commit()

    return {
        "ret": "OK",
        "cloudtime": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "imported": imported,
    }

@router.get("/status")
async def adms_status():
    """Endpoint de vérification — les terminaux pingent ici pour tester."""
    return {
        "ret": "OK",
        "version": "VigiTime 1.0",
        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
