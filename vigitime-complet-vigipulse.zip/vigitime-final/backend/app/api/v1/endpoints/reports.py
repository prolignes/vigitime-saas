"""Rapports — summary, anomalies, PDF, paie."""
from typing import Optional
from uuid import UUID
from datetime import date
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
import io

from app.db.session import get_db
from app.core.security import get_current_user
from app.services.report_service import ReportService
from app.services.attendance_service import AttendanceService

router = APIRouter()

def get_svc(current_user=Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    return ReportService(db, current_user.tenant_id)


@router.get("/summary")
async def summary(
    date_from: date = Query(default=date.today().replace(day=1)),
    date_to:   date = Query(default=date.today()),
    dept_id:   Optional[UUID] = None,
    svc: ReportService = Depends(get_svc),
):
    return await svc.get_summary(date_from, date_to, dept_id)


@router.get("/anomalies")
async def anomalies(svc: ReportService = Depends(get_svc)):
    return await svc.get_anomalies()


@router.get("/pdf/summary")
async def pdf_summary(
    date_from: date = Query(default=date.today().replace(day=1)),
    date_to:   date = Query(default=date.today()),
    svc: ReportService = Depends(get_svc),
):
    pdf_bytes = await svc.generate_pdf_summary(date_from, date_to)
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=rapport_{date_from}_{date_to}.pdf"},
    )
