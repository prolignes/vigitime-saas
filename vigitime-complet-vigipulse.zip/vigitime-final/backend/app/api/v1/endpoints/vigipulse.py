"""
VigiPulse — Endpoints API
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.deps import get_current_user, get_current_tenant_id
from app.models.user import User
from app.services.vigipulse_service import VigiPulseService

router = APIRouter(prefix="/vigipulse", tags=["VigiPulse"])
service = VigiPulseService()


@router.get("/tenant")
async def get_tenant_pulse(
    tenant_id: str = Depends(get_current_tenant_id),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Score VigiPulse global — tous les employés du tenant."""
    return await service.compute_tenant_pulse(db=db, tenant_id=tenant_id)


@router.get("/employee/{employee_id}")
async def get_employee_pulse(
    employee_id: str,
    tenant_id: str = Depends(get_current_tenant_id),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Score VigiPulse détaillé pour un employé."""
    pulse = await service.compute_employee_pulse(
        db=db,
        tenant_id=tenant_id,
        employee_id=employee_id,
    )
    return vars(pulse)
