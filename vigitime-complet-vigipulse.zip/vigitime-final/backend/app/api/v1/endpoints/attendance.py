from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from typing import Optional
import datetime
from app.core.database import get_db
from app.models.attendance import AttendanceRecord, LeaveRequest, Timetable
from app.models.employee import Employee
from app.schemas.attendance import AttendanceCreate, AttendanceOut, LeaveCreate, LeaveOut
from app.services.attendance_service import attendance_service

router = APIRouter(prefix="/attendance", tags=["Attendance"])

async def get_tenant_id() -> str:
    return "demo-tenant"

@router.get("", response_model=list[AttendanceOut])
async def list_attendance(
    date_from: Optional[datetime.date] = None,
    date_to: Optional[datetime.date] = None,
    employee_id: Optional[str] = None,
    status: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    q = select(AttendanceRecord).where(AttendanceRecord.tenant_id == tenant_id)
    if date_from:
        q = q.where(AttendanceRecord.date >= date_from)
    if date_to:
        q = q.where(AttendanceRecord.date <= date_to)
    if employee_id:
        q = q.where(AttendanceRecord.employee_id == employee_id)
    if status:
        q = q.where(AttendanceRecord.status == status)
    q = q.order_by(AttendanceRecord.date.desc()).offset((page-1)*page_size).limit(page_size)
    result = await db.execute(q)
    return [AttendanceOut.model_validate(r) for r in result.scalars().all()]

@router.post("", response_model=AttendanceOut, status_code=201)
async def create_record(
    data: AttendanceCreate,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    # Chercher le timetable associé à l'employé
    timetable = None
    tt_result = await db.execute(
        select(Timetable).where(Timetable.tenant_id == tenant_id).limit(1)
    )
    timetable = tt_result.scalar_one_or_none()

    # Calculer durées
    durations = {}
    if data.check_in and data.check_out:
        brk = timetable.break_minutes if timetable else 60
        durations = attendance_service.calc_duration(data.check_in, data.check_out, brk)

    # Calculer statut
    status = attendance_service.calc_status(
        data.check_in,
        timetable.start_time if timetable else None,
        timetable.late_tolerance if timetable else 15
    )
    late_min = attendance_service.calc_late_minutes(
        data.check_in,
        timetable.start_time if timetable else None
    )

    rec = AttendanceRecord(
        tenant_id=tenant_id,
        **data.model_dump(),
        status=status,
        late_minutes=late_min,
        **durations
    )
    db.add(rec)
    await db.flush()
    return AttendanceOut.model_validate(rec)

@router.get("/stats/{employee_id}")
async def get_stats(
    employee_id: str,
    date_from: Optional[datetime.date] = None,
    date_to: Optional[datetime.date] = None,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return await attendance_service.get_employee_stats(
        db, tenant_id, employee_id, date_from, date_to
    )

@router.get("/department-stats")
async def get_dept_stats(
    date_from: datetime.date = Query(...),
    date_to: datetime.date = Query(...),
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    return await attendance_service.get_department_stats(db, tenant_id, date_from, date_to)

# ── Congés ──
@router.get("/leaves", response_model=list[LeaveOut])
async def list_leaves(
    employee_id: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    q = select(LeaveRequest).where(LeaveRequest.tenant_id == tenant_id)
    if employee_id:
        q = q.where(LeaveRequest.employee_id == employee_id)
    if status:
        q = q.where(LeaveRequest.status == status)
    result = await db.execute(q.order_by(LeaveRequest.created_at.desc()))
    return [LeaveOut.model_validate(r) for r in result.scalars().all()]

@router.post("/leaves", response_model=LeaveOut, status_code=201)
async def create_leave(
    data: LeaveCreate,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    # Calculer jours ouvrés (simple — sans config weekend ici)
    delta = (data.end_date - data.start_date).days + 1
    working_days = sum(
        1 for i in range(delta)
        if (data.start_date + datetime.timedelta(days=i)).weekday() not in [4, 5]
    )
    leave = LeaveRequest(tenant_id=tenant_id, working_days=working_days, **data.model_dump())
    db.add(leave)
    await db.flush()
    return LeaveOut.model_validate(leave)

@router.patch("/leaves/{leave_id}/approve")
async def approve_leave(
    leave_id: str,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    result = await db.execute(
        select(LeaveRequest).where(
            and_(LeaveRequest.id == leave_id, LeaveRequest.tenant_id == tenant_id)
        )
    )
    leave = result.scalar_one_or_none()
    if not leave:
        raise HTTPException(404, "Demande introuvable")
    leave.status = "approved"
    leave.approved_at = datetime.datetime.now().isoformat()
    # TODO: créer les enregistrements d'absence correspondants
    return {"status": "approved"}

@router.patch("/leaves/{leave_id}/reject")
async def reject_leave(
    leave_id: str,
    reason: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    result = await db.execute(
        select(LeaveRequest).where(
            and_(LeaveRequest.id == leave_id, LeaveRequest.tenant_id == tenant_id)
        )
    )
    leave = result.scalar_one_or_none()
    if not leave:
        raise HTTPException(404, "Demande introuvable")
    leave.status = "rejected"
    if reason:
        leave.rejection_reason = reason
    return {"status": "rejected"}
