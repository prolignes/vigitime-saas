from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Optional
import asyncio, datetime
from app.core.database import get_db
from app.models.device import Device

router = APIRouter(prefix="/devices", tags=["Devices"])

async def get_tenant_id() -> str:
    return "demo-tenant"

@router.get("")
async def list_devices(
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    result = await db.execute(
        select(Device).where(Device.tenant_id == tenant_id)
    )
    devices = result.scalars().all()
    return [
        {
            "id": d.id, "name": d.name, "ip_address": d.ip_address,
            "port": d.port, "model": d.model, "brand": d.brand,
            "status": d.status, "last_sync_at": d.last_sync_at,
            "total_records": d.total_records, "firmware": d.firmware,
            "area": d.area, "location": d.location
        }
        for d in devices
    ]

@router.post("/{device_id}/ping")
async def ping_device(
    device_id: str,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    result = await db.execute(
        select(Device).where(
            and_(Device.id == device_id, Device.tenant_id == tenant_id)
        )
    )
    device = result.scalar_one_or_none()
    if not device:
        raise HTTPException(404, "Terminal introuvable")

    try:
        from zk import ZK
        conn = ZK(device.ip_address, port=device.port, timeout=5, password=device.comm_key).connect()
        info = {
            "device_name": conn.get_device_name(),
            "serial": conn.get_serialnumber(),
            "firmware": conn.get_firmware_version(),
            "users_count": len(conn.get_users())
        }
        conn.disconnect()
        device.status = "online"
        device.last_sync_at = datetime.datetime.now().isoformat()
        return {"status": "success", "device": info}
    except ImportError:
        # Mode démo si zklib non installé
        device.status = "online"
        return {"status": "success", "device": {
            "device_name": f"{device.brand} {device.model} [DÉMO]",
            "serial": device.serial_number or "DEMO-SN",
            "firmware": device.firmware or "Ver 6.60",
            "users_count": 24
        }}
    except Exception as e:
        device.status = "offline"
        return {"status": "error", "message": str(e), "tips": [
            f"Vérifier IP {device.ip_address} accessible",
            "Port 4370 ouvert",
            "Menu Comm → Comm Key = 0"
        ]}

@router.post("/{device_id}/sync")
async def sync_device(
    device_id: str,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    tenant_id: str = Depends(get_tenant_id)
):
    result = await db.execute(
        select(Device).where(
            and_(Device.id == device_id, Device.tenant_id == tenant_id)
        )
    )
    device = result.scalar_one_or_none()
    if not device:
        raise HTTPException(404, "Terminal introuvable")

    # En production: lancer tâche Celery
    return {"status": "sync_started", "device_id": device_id}
