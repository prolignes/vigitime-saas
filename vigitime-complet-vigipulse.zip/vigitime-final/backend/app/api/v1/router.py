from fastapi import APIRouter
from app.api.v1.endpoints import auth, employees, attendance, devices, adms, reports, tenants, vigipulse

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth.router)
api_router.include_router(employees.router)
api_router.include_router(attendance.router)
api_router.include_router(devices.router)
api_router.include_router(adms.router)
api_router.include_router(reports.router)
api_router.include_router(tenants.router)
api_router.include_router(vigipulse.router)
