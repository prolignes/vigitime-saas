#!/bin/bash
set -e

echo "═══════════════════════════════════════════"
echo "   VigiTime SaaS — Démarrage"
echo "═══════════════════════════════════════════"

# Créer .env si absent
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✓ .env créé depuis .env.example"
fi

# Lancer Docker Compose
echo ""
echo "▶ Démarrage des services..."
docker-compose up -d --build

# Attendre PostgreSQL
echo ""
echo "⏳ Attente de la base de données..."
until docker exec vigitime_db pg_isready -U vigitime > /dev/null 2>&1; do
    sleep 2
done
echo "✓ Base de données prête"

# Migrations
echo ""
echo "▶ Exécution des migrations..."
docker exec vigitime_api alembic upgrade head
echo "✓ Migrations appliquées"

# Seed
echo ""
echo "▶ Chargement des données initiales..."
docker exec vigitime_api python app/db/seed.py
echo "✓ Données initiales chargées"

echo ""
echo "═══════════════════════════════════════════"
echo "   VigiTime est démarré !"
echo "═══════════════════════════════════════════"
echo ""
echo "   Interface :    http://localhost:3000"
echo "   API :          http://localhost:8000"
echo "   Documentation: http://localhost:8000/api/docs"
echo ""
echo "   Connexion démo :"
echo "   admin@vigitime.dz / admin123  (Super Admin)"
echo "   rh@vigitime.dz    / rh123     (Responsable RH)"
echo "   sup@vigitime.dz   / sup123    (Superviseur)"
echo ""
echo "   Kiosque employé : http://localhost:3000/selfservice"
echo "═══════════════════════════════════════════"
