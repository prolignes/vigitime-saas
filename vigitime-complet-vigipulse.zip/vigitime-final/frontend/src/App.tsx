import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useAuthStore } from '@/lib/store'
import { Layout } from '@/components/layout/Layout'
import { Login }      from '@/pages/Login'
import { Dashboard }  from '@/pages/Dashboard'
import { Employees }  from '@/pages/Employees'
import { Attendance } from '@/pages/Attendance'
import { Leaves }     from '@/pages/Leaves'
import { Reports }    from '@/pages/Reports'
import { Devices }    from '@/pages/Devices'
import { Settings }   from '@/pages/Settings'
import { SelfService }from '@/pages/SelfService'
import { VigiPulse }  from '@/pages/VigiPulse'

const qc = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 60_000, retry: 1, refetchOnWindowFocus: false }
  }
})

const Guard = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuthStore()
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        <Routes>
          <Route path="/login"       element={<Login />} />
          <Route path="/selfservice" element={<SelfService />} />
              <Route path="/vigipulse"   element={<VigiPulse />} />
          <Route path="/" element={<Guard><Layout /></Guard>}>
            <Route index                  element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard"       element={<Dashboard />} />
            <Route path="employees"       element={<Employees />} />
            <Route path="attendance"      element={<Attendance />} />
            <Route path="leaves"          element={<Leaves />} />
            <Route path="reports"         element={<Reports />} />
            <Route path="devices"         element={<Devices />} />
            <Route path="settings"        element={<Settings />} />
            <Route path="*"               element={<Navigate to="/dashboard" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}
