import { clsx } from 'clsx'

interface BadgeProps {
  variant?: 'green' | 'red' | 'orange' | 'blue' | 'gray' | 'purple'
  size?: 'sm' | 'md'
  children: React.ReactNode
  className?: string
}

export const Badge = ({ variant = 'gray', size = 'sm', children, className }: BadgeProps) => (
  <span className={clsx(
    'inline-flex items-center font-medium rounded-full',
    {
      'bg-green-100 text-green-800': variant === 'green',
      'bg-red-100 text-red-800': variant === 'red',
      'bg-orange-100 text-orange-800': variant === 'orange',
      'bg-blue-100 text-blue-800': variant === 'blue',
      'bg-gray-100 text-gray-700': variant === 'gray',
      'bg-purple-100 text-purple-800': variant === 'purple',
    },
    { 'px-2 py-0.5 text-xs': size === 'sm', 'px-3 py-1 text-sm': size === 'md' },
    className
  )}>
    {children}
  </span>
)

export const StatusBadge = ({ status }: { status: string }) => {
  const map: Record<string, { label: string; variant: BadgeProps['variant'] }> = {
    on_time:    { label: 'À l\'heure', variant: 'green' },
    late:       { label: 'Retard',     variant: 'orange' },
    absent:     { label: 'Absent',     variant: 'red' },
    early_leave:{ label: 'Sortie anticipée', variant: 'blue' },
    leave:      { label: 'Congé',      variant: 'purple' },
    active:     { label: 'Actif',      variant: 'green' },
    inactive:   { label: 'Inactif',    variant: 'gray' },
    resigned:   { label: 'Démissionnaire', variant: 'red' },
    pending:    { label: 'En attente', variant: 'orange' },
    approved:   { label: 'Approuvé',   variant: 'green' },
    rejected:   { label: 'Refusé',     variant: 'red' },
    online:     { label: 'En ligne',   variant: 'green' },
    offline:    { label: 'Hors ligne', variant: 'red' },
  }
  const cfg = map[status] || { label: status, variant: 'gray' as const }
  return <Badge variant={cfg.variant}>{cfg.label}</Badge>
}
