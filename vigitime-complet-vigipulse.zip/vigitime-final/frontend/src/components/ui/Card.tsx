import { clsx } from 'clsx'

interface CardProps {
  children: React.ReactNode
  className?: string
  padding?: boolean
}

export const Card = ({ children, className, padding = true }: CardProps) => (
  <div className={clsx(
    'bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm',
    padding && 'p-6',
    className
  )}>
    {children}
  </div>
)

interface StatCardProps {
  label: string
  value: string | number
  sub?: string
  color?: 'blue' | 'green' | 'orange' | 'red' | 'purple'
  icon?: React.ReactNode
  trend?: { value: number; label: string }
}

export const StatCard = ({ label, value, sub, color = 'blue', icon, trend }: StatCardProps) => {
  const colors = {
    blue:   'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/30',
    green:  'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30',
    orange: 'border-amber-500 bg-amber-50 dark:bg-amber-950/30',
    red:    'border-red-500 bg-red-50 dark:bg-red-950/30',
    purple: 'border-purple-500 bg-purple-50 dark:bg-purple-950/30',
  }
  const textColors = {
    blue: 'text-indigo-600 dark:text-indigo-400',
    green: 'text-emerald-600 dark:text-emerald-400',
    orange: 'text-amber-600 dark:text-amber-400',
    red: 'text-red-600 dark:text-red-400',
    purple: 'text-purple-600 dark:text-purple-400',
  }

  return (
    <div className={clsx(
      'rounded-xl border-l-4 p-5 flex items-center gap-4 shadow-sm',
      colors[color]
    )}>
      {icon && (
        <div className={clsx('shrink-0', textColors[color])}>
          {icon}
        </div>
      )}
      <div className="min-w-0 flex-1">
        <div className={clsx('text-2xl font-bold leading-none', textColors[color])}>
          {value}
        </div>
        <div className="text-sm font-medium text-gray-600 dark:text-gray-400 mt-1">{label}</div>
        {sub && <div className="text-xs text-gray-500 mt-0.5">{sub}</div>}
        {trend && (
          <div className={clsx('text-xs mt-1 font-medium',
            trend.value >= 0 ? 'text-emerald-600' : 'text-red-600'
          )}>
            {trend.value >= 0 ? '+' : ''}{trend.value}% {trend.label}
          </div>
        )}
      </div>
    </div>
  )
}
