import { NavLink, useLocation } from 'react-router-dom'
import { clsx } from 'clsx'
import {
  LayoutDashboard, Users, Building2, Clock, Calendar,
  Umbrella, BarChart3, Monitor, Settings, ChevronRight,
  Clock4, UserCheck, LogOut, ChevronDown, Heart
} from 'lucide-react'
import { useAuthStore, useUIStore } from '@/lib/store'
import { useState } from 'react'

const NAV = [
  {
    section: 'Principal',
    items: [
      { to: '/dashboard', icon: LayoutDashboard, label: 'Tableau de bord' },
    ]
  },
  {
    section: 'Personnel',
    items: [
      { to: '/employees', icon: Users, label: 'Employés' },
      { to: '/departments', icon: Building2, label: 'Départements' },
    ]
  },
  {
    section: 'Présence',
    items: [
      { to: '/attendance', icon: Clock, label: 'Pointages' },
      { to: '/schedule', icon: Calendar, label: 'Planning' },
      { to: '/leaves', icon: Umbrella, label: 'Congés' },
      { to: '/overtime', icon: Clock4, label: 'Heures supp.' },
    ]
  },
  {
    section: 'Gestion',
    items: [
      { to: '/reports',   icon: BarChart3, label: 'Rapports' },
      { to: '/vigipulse', icon: Heart,    label: 'VigiPulse IA' },
      { to: '/devices',   icon: Monitor,  label: 'Terminaux' },
      { to: '/selfservice', icon: UserCheck, label: 'Kiosque' },
    ]
  },
  {
    section: 'Système',
    items: [
      { to: '/settings', icon: Settings, label: 'Paramètres' },
    ]
  },
]

export const Sidebar = () => {
  const { sidebarOpen } = useUIStore()
  const { user, logout } = useAuthStore()
  const [collapsed, setCollapsed] = useState<string[]>([])

  const toggleSection = (section: string) => {
    setCollapsed(prev =>
      prev.includes(section) ? prev.filter(s => s !== section) : [...prev, section]
    )
  }

  return (
    <aside className={clsx(
      'fixed left-0 top-0 h-full bg-gray-950 flex flex-col transition-all duration-300 z-50',
      sidebarOpen ? 'w-60' : 'w-16'
    )}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-800">
        <img src="/logo_vigitime.png" alt="VigiTime" className="w-9 h-9 object-contain shrink-0" />
        {sidebarOpen && (
          <div>
            <div className="text-white font-bold text-base leading-none tracking-wide">
              Vigi<span style={{color:'#0EA5E9'}}>Time</span>
            </div>
            <div className="text-gray-500 text-xs mt-0.5">v1.0 SaaS</div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 px-2">
        {NAV.map(({ section, items }) => (
          <div key={section} className="mb-4">
            {sidebarOpen && (
              <button
                onClick={() => toggleSection(section)}
                className="flex items-center justify-between w-full px-3 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:text-gray-400 transition-colors"
              >
                {section}
                <ChevronDown className={clsx('w-3 h-3 transition-transform',
                  collapsed.includes(section) && '-rotate-90'
                )} />
              </button>
            )}
            {!collapsed.includes(section) && items.map(({ to, icon: Icon, label }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) => clsx(
                  'flex items-center gap-3 px-3 py-2.5 rounded-xl mt-0.5 transition-all group',
                  isActive
                    ? 'bg-sky-500 text-white shadow-lg shadow-sky-900/40'
                    : 'text-gray-400 hover:bg-gray-800/60 hover:text-white'
                )}
                title={!sidebarOpen ? label : undefined}
              >
                <Icon className="w-4.5 h-4.5 shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">{label}</span>}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      {/* User */}
      {user && (
        <div className="border-t border-gray-800 p-3">
          <div className={clsx('flex items-center gap-3', !sidebarOpen && 'justify-center')}>
            <div className="w-8 h-8 rounded-full bg-sky-600 flex items-center justify-center text-white text-sm font-bold shrink-0">
              {user.full_name?.[0] || 'U'}
            </div>
            {sidebarOpen && (
              <>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium truncate">{user.full_name}</div>
                  <div className="text-gray-500 text-xs truncate">{user.role}</div>
                </div>
                <button
                  onClick={logout}
                  className="text-gray-500 hover:text-red-400 transition-colors"
                  title="Déconnexion"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </aside>
  )
}
