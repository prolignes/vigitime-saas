import { Outlet } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar'
import { useUIStore } from '@/lib/store'
import { clsx } from 'clsx'
import { useEffect } from 'react'

export const Layout = () => {
  const { sidebarOpen, theme } = useUIStore()

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [theme])

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex">
      <Sidebar />
      <div className={clsx(
        'flex-1 flex flex-col transition-all duration-300 min-w-0',
        sidebarOpen ? 'ml-60' : 'ml-16'
      )}>
        <Topbar />
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
