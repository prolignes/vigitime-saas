import { Bell, Moon, Sun, Menu, Search, Globe } from 'lucide-react'
import { useUIStore, useAuthStore } from '@/lib/store'
import { clsx } from 'clsx'

interface TopbarProps {
  title?: string
  actions?: React.ReactNode
}

export const Topbar = ({ title, actions }: TopbarProps) => {
  const { theme, toggleTheme, setSidebarOpen, sidebarOpen, lang, setLang } = useUIStore()
  const { user } = useAuthStore()

  return (
    <header className="h-16 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 flex items-center gap-4 px-6 sticky top-0 z-40">
      {/* Hamburger */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
      >
        <Menu className="w-5 h-5" />
      </button>

      {/* Breadcrumb/title */}
      {title && (
        <h1 className="text-base font-semibold text-gray-900 dark:text-white hidden sm:block">
          {title}
        </h1>
      )}

      {/* Search */}
      <div className="flex-1 max-w-md hidden md:flex items-center gap-2 bg-gray-100 dark:bg-gray-800 rounded-xl px-3 py-2">
        <Search className="w-4 h-4 text-gray-400 shrink-0" />
        <input
          type="text"
          placeholder="Rechercher..."
          className="bg-transparent text-sm text-gray-700 dark:text-gray-300 placeholder:text-gray-400 outline-none w-full"
        />
      </div>

      <div className="flex-1" />

      {/* Actions */}
      {actions}

      {/* Lang toggle */}
      <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden text-xs font-semibold">
        <button
          onClick={() => setLang('fr')}
          className={clsx('px-2.5 py-1.5 transition-colors',
            lang === 'fr' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
          )}
        >FR</button>
        <button
          onClick={() => setLang('ar')}
          className={clsx('px-2.5 py-1.5 transition-colors',
            lang === 'ar' ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
          )}
        >ع</button>
      </div>

      {/* Theme */}
      <button
        onClick={toggleTheme}
        className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
      >
        {theme === 'dark' ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
      </button>

      {/* Notifications */}
      <button className="relative w-9 h-9 rounded-xl flex items-center justify-center text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
        <Bell className="w-4.5 h-4.5" />
        <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
      </button>

      {/* Avatar */}
      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold cursor-pointer">
        {user?.full_name?.[0] || 'U'}
      </div>
    </header>
  )
}
