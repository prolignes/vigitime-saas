import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

export const api = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  headers: { 'Content-Type': 'application/json' },
})

// Injecter le token JWT automatiquement
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Rafraîchir le token automatiquement sur 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    if (error.response?.status === 401) {
      const refreshToken = localStorage.getItem('refresh_token')
      if (refreshToken) {
        try {
          const { data } = await axios.post(`${BASE_URL}/api/v1/auth/refresh`, { refresh_token: refreshToken })
          localStorage.setItem('access_token', data.access_token)
          error.config.headers.Authorization = `Bearer ${data.access_token}`
          return api(error.config)
        } catch {
          localStorage.clear()
          window.location.href = '/login'
        }
      }
    }
    return Promise.reject(error)
  }
)

// ── API functions ──
export const authApi = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  me: () => api.get('/auth/me'),
}

export const employeesApi = {
  list: (params?: Record<string, any>) =>
    api.get('/employees', { params }),
  get: (id: string) => api.get(`/employees/${id}`),
  create: (data: any) => api.post('/employees', data),
  update: (id: string, data: any) => api.patch(`/employees/${id}`, data),
  delete: (id: string) => api.delete(`/employees/${id}`),
  uploadPhoto: (id: string, file: File) => {
    const form = new FormData()
    form.append('file', file)
    return api.post(`/employees/${id}/photo`, form, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },
}

export const attendanceApi = {
  list: (params?: Record<string, any>) =>
    api.get('/attendance', { params }),
  create: (data: any) => api.post('/attendance', data),
  stats: (employeeId: string, params?: any) =>
    api.get(`/attendance/stats/${employeeId}`, { params }),
  deptStats: (params: any) =>
    api.get('/attendance/department-stats', { params }),
  leaves: {
    list: (params?: any) => api.get('/attendance/leaves', { params }),
    create: (data: any) => api.post('/attendance/leaves', data),
    approve: (id: string) => api.patch(`/attendance/leaves/${id}/approve`),
    reject: (id: string, reason?: string) =>
      api.patch(`/attendance/leaves/${id}/reject`, { reason }),
  }
}

export const devicesApi = {
  list: () => api.get('/devices'),
  ping: (id: string) => api.post(`/devices/${id}/ping`),
  sync: (id: string) => api.post(`/devices/${id}/sync`),
}
