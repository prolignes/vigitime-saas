import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface User {
  id: string
  email: string
  full_name: string
  role: string
  tenant_id: string
  avatar_url?: string
}

interface AuthState {
  user: User | null
  access_token: string | null
  refresh_token: string | null
  isAuthenticated: boolean
  setAuth: (user: User, access_token: string, refresh_token: string) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      access_token: null,
      refresh_token: null,
      isAuthenticated: false,
      setAuth: (user, access_token, refresh_token) => {
        localStorage.setItem('access_token', access_token)
        localStorage.setItem('refresh_token', refresh_token)
        set({ user, access_token, refresh_token, isAuthenticated: true })
      },
      logout: () => {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        set({ user: null, access_token: null, refresh_token: null, isAuthenticated: false })
      },
    }),
    { name: 'vigitime-auth', partialize: (s) => ({ user: s.user, access_token: s.access_token, refresh_token: s.refresh_token, isAuthenticated: s.isAuthenticated }) }
  )
)

interface UIState {
  sidebarOpen: boolean
  theme: 'light' | 'dark'
  lang: 'fr' | 'ar'
  setSidebarOpen: (v: boolean) => void
  toggleTheme: () => void
  setLang: (l: 'fr' | 'ar') => void
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      theme: 'light',
      lang: 'fr',
      setSidebarOpen: (v) => set({ sidebarOpen: v }),
      toggleTheme: () => set((s) => ({ theme: s.theme === 'light' ? 'dark' : 'light' })),
      setLang: (l) => set({ lang: l }),
    }),
    { name: 'vigitime-ui' }
  )
)
