export interface Employee {
  id: string
  tenant_id: string
  matricule: string
  first_name: string
  last_name: string
  full_name?: string
  gender?: string
  birth_date?: string
  nationality?: string
  email?: string
  phone?: string
  address?: string
  department_id?: string
  department?: Department
  position_id?: string
  position?: Position
  hire_date?: string
  hourly_rate: number
  badge_nfc?: string
  status: 'active' | 'inactive' | 'resigned' | 'on_leave'
  photo_url?: string
  created_at: string
  updated_at: string
}

export interface Department {
  id: string
  code: string
  name: string
  manager_id?: string
  is_active: boolean
}

export interface Position {
  id: string
  title: string
  department_id?: string
  hourly_rate: number
}

export interface AttendanceRecord {
  id: string
  employee_id: string
  employee?: Employee
  date: string
  check_in?: string
  check_out?: string
  work_minutes: number
  overtime_minutes: number
  late_minutes: number
  status: 'on_time' | 'late' | 'absent' | 'early_leave' | 'leave'
  method: string
  is_approved: boolean
  note?: string
}

export interface LeaveRequest {
  id: string
  employee_id: string
  employee?: Employee
  leave_type: 'vacation' | 'sick' | 'personal' | 'maternity'
  start_date: string
  end_date: string
  working_days: number
  reason?: string
  status: 'pending' | 'approved' | 'rejected' | 'cancelled'
  created_at: string
}

export interface Device {
  id: string
  name: string
  ip_address: string
  port: number
  model?: string
  brand?: string
  firmware?: string
  status: 'online' | 'offline'
  last_sync_at?: string
  total_records: number
  area?: string
  location?: string
}

export interface AttendanceStats {
  total_days: number
  present: number
  late: number
  absent: number
  work_hours: number
  overtime_hours: number
  attendance_rate: number
}

export type UserRole = 'super_admin' | 'admin' | 'rh' | 'supervisor' | 'viewer' | 'employee'
