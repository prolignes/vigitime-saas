import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Building2, Clock, Users, Shield, Bell } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Input, Select } from '@/components/ui/Input'
import { Topbar } from '@/components/layout/Topbar'
import { useAuthStore } from '@/lib/store'

const TABS = [
  { id: 'company',   label: 'Société',      icon: Building2 },
  { id: 'schedule',  label: 'Horaires',     icon: Clock },
  { id: 'users',     label: 'Utilisateurs', icon: Users },
  { id: 'security',  label: 'Sécurité',     icon: Shield },
  { id: 'notif',     label: 'Notifications',icon: Bell },
]

export const Settings = () => {
  const [tab, setTab] = useState('company')
  const { user } = useAuthStore()

  return (
    <>
      <Topbar title="Paramètres" />
      <div className="p-6">
        <div className="flex gap-6">
          {/* Sidebar tabs */}
          <div className="w-48 shrink-0">
            <nav className="space-y-1">
              {TABS.map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => setTab(id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                    tab === id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}>
                  <Icon className="w-4 h-4 shrink-0" />
                  {label}
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1">
            {tab === 'company' && (
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
                <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800">
                  <h2 className="font-semibold text-gray-900 dark:text-white">Informations de l'entreprise</h2>
                </div>
                <div className="p-6 space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    <Input label="Nom de l'entreprise" defaultValue="Entreprise Algérienne SARL" required />
                    <Input label="Slug / Identifiant" defaultValue="demo-dz" className="font-mono" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Input label="Email" type="email" defaultValue="contact@entreprise.dz" />
                    <Input label="Téléphone" defaultValue="+213 21 00 00 00" />
                  </div>
                  <Input label="Adresse" defaultValue="Alger, Algérie" />
                  <div className="grid grid-cols-3 gap-4">
                    <Select label="Fuseau horaire">
                      <option value="Africa/Algiers">Africa/Algiers (UTC+1)</option>
                      <option value="Europe/Paris">Europe/Paris (UTC+2)</option>
                    </Select>
                    <Select label="Langue">
                      <option value="fr">Français</option>
                      <option value="ar">العربية</option>
                    </Select>
                    <Select label="Devise">
                      <option value="DZD">DZD — Dinar Algérien</option>
                      <option value="EUR">EUR — Euro</option>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Jours de week-end
                    </label>
                    <div className="flex gap-2">
                      {['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'].map((d, i) => (
                        <label key={i} className="flex flex-col items-center gap-1 cursor-pointer">
                          <input type="checkbox" defaultChecked={i === 4 || i === 5}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                          <span className="text-xs text-gray-500">{d}</span>
                        </label>
                      ))}
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Par défaut : Vendredi + Samedi (standard algérien)</p>
                  </div>
                  <div className="flex justify-end">
                    <Button>Enregistrer</Button>
                  </div>
                </div>
              </div>
            )}

            {tab === 'schedule' && (
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
                <div className="px-6 py-4 border-b border-gray-100 dark:border-gray-800 flex items-center justify-between">
                  <h2 className="font-semibold text-gray-900 dark:text-white">Créneaux horaires</h2>
                  <Button size="sm">Ajouter créneau</Button>
                </div>
                <div className="divide-y divide-gray-50 dark:divide-gray-800">
                  {[
                    { name: 'Shift Standard',    start: '09:00', end: '17:00', break: 60, late: 15 },
                    { name: 'Shift Matin',        start: '06:00', end: '14:00', break: 30, late: 10 },
                    { name: 'Shift Après-midi',   start: '14:00', end: '22:00', break: 30, late: 10 },
                    { name: 'Shift de Nuit',      start: '22:00', end: '06:00', break: 30, late: 15 },
                  ].map((s, i) => (
                    <div key={i} className="flex items-center gap-4 px-6 py-4">
                      <div className="flex-1">
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs text-gray-400 mt-0.5">
                          {s.start} → {s.end} · Pause {s.break}min · Tolérance retard {s.late}min
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full font-medium">Actif</span>
                        <button className="text-xs text-indigo-600 hover:underline">Modifier</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === 'security' && (
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6 space-y-5">
                <h2 className="font-semibold text-gray-900 dark:text-white">Sécurité</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <div>
                      <div className="font-medium text-sm">JWT Access Token</div>
                      <div className="text-xs text-gray-400">Expire toutes les 8 heures</div>
                    </div>
                    <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">Actif</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <div>
                      <div className="font-medium text-sm">Refresh Token</div>
                      <div className="text-xs text-gray-400">Valide 30 jours</div>
                    </div>
                    <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-medium">Actif</span>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-xl">
                    <div>
                      <div className="font-medium text-sm">Authentification à 2 facteurs (2FA)</div>
                      <div className="text-xs text-gray-400">TOTP — Google Authenticator</div>
                    </div>
                    <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded-full font-medium">Bientôt</span>
                  </div>
                </div>
                <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                  <h3 className="font-medium text-sm text-gray-900 dark:text-white mb-3">Changer le mot de passe</h3>
                  <div className="space-y-3">
                    <Input label="Mot de passe actuel" type="password" />
                    <Input label="Nouveau mot de passe" type="password" hint="Minimum 8 caractères" />
                    <Input label="Confirmer" type="password" />
                    <Button size="sm">Mettre à jour</Button>
                  </div>
                </div>
              </div>
            )}

            {tab === 'notif' && (
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6 space-y-5">
                <h2 className="font-semibold text-gray-900 dark:text-white">Notifications</h2>
                {[
                  { label: 'Nouveau pointage reçu',         desc: 'Quand un terminal envoie un pointage' },
                  { label: 'Retard détecté',                 desc: 'Alerte quand un employé est en retard' },
                  { label: 'Absence injustifiée',            desc: 'Employé absent sans congé approuvé' },
                  { label: 'Demande de congé soumise',       desc: 'Un employé a fait une demande' },
                  { label: 'Terminal hors ligne',            desc: 'Un terminal ZKTeco ne répond plus' },
                  { label: 'Rapport hebdomadaire',           desc: 'Résumé envoyé chaque lundi matin' },
                ].map((n, i) => (
                  <div key={i} className="flex items-center justify-between py-3 border-b border-gray-50 dark:border-gray-800">
                    <div>
                      <div className="font-medium text-sm">{n.label}</div>
                      <div className="text-xs text-gray-400">{n.desc}</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={i < 4} className="sr-only peer" />
                      <div className="w-10 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    </label>
                  </div>
                ))}
                <div className="flex justify-end">
                  <Button>Enregistrer les préférences</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  )
}
