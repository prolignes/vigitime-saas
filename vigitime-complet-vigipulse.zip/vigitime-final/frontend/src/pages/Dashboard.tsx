import { useQuery } from '@tanstack/react-query'
import {
  Users, UserCheck, Clock, AlertTriangle, Monitor,
  TrendingUp, Activity
} from 'lucide-react'
import { StatCard } from '@/components/ui/Card'
import { Topbar } from '@/components/layout/Topbar'
import { employeesApi, attendanceApi, devicesApi } from '@/lib/api'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from 'recharts'

const COLORS = ['#6366f1', '#f59e0b', '#ef4444']

export const Dashboard = () => {
  const today = new Date().toISOString().split('T')[0]
  const sevenDaysAgo = new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0]

  const { data: employees } = useQuery({
    queryKey: ['employees', 'summary'],
    queryFn: () => employeesApi.list({ page_size: 1 }),
  })

  const { data: attendance } = useQuery({
    queryKey: ['attendance', today],
    queryFn: () => attendanceApi.list({ date_from: sevenDaysAgo, date_to: today, page_size: 100 }),
  })

  const { data: devices } = useQuery({
    queryKey: ['devices'],
    queryFn: () => devicesApi.list(),
  })

  const records = attendance?.data || []
  const devList = devices?.data || []

  const todayRecords = records.filter((r: any) => r.date === today)
  const present = todayRecords.filter((r: any) => r.status !== 'absent').length
  const late = todayRecords.filter((r: any) => r.status === 'late').length
  const absent = todayRecords.filter((r: any) => r.status === 'absent').length
  const online = devList.filter((d: any) => d.status === 'online').length

  // Trend data (7 jours)
  const trendData = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000)
    const dateStr = d.toISOString().split('T')[0]
    const dayRecords = records.filter((r: any) => r.date === dateStr)
    return {
      day: d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' }),
      Présents: dayRecords.filter((r: any) => r.status !== 'absent').length,
      Retards: dayRecords.filter((r: any) => r.status === 'late').length,
      Absents: dayRecords.filter((r: any) => r.status === 'absent').length,
    }
  })

  const pieData = [
    { name: 'Présents', value: present - late },
    { name: 'Retards', value: late },
    { name: 'Absents', value: absent },
  ].filter(d => d.value > 0)

  return (
    <>
      <Topbar title="Tableau de bord" />
      <div className="p-6 space-y-6">

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Employés actifs"
            value={employees?.data?.total || 0}
            icon={<Users className="w-8 h-8" />}
            color="blue"
          />
          <StatCard
            label="Présents aujourd'hui"
            value={present}
            sub={`${employees?.data?.total ? Math.round(present / employees.data.total * 100) : 0}% de l'effectif`}
            icon={<UserCheck className="w-8 h-8" />}
            color="green"
          />
          <StatCard
            label="Retards"
            value={late}
            icon={<Clock className="w-8 h-8" />}
            color="orange"
          />
          <StatCard
            label="Terminaux en ligne"
            value={`${online}/${devList.length}`}
            icon={<Monitor className="w-8 h-8" />}
            color={online === devList.length ? 'green' : online > 0 ? 'orange' : 'red'}
          />
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* Bar chart trend */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Présence — 7 derniers jours</h3>
                <p className="text-sm text-gray-500 mt-0.5">Évolution journalière</p>
              </div>
              <TrendingUp className="w-4 h-4 text-gray-400" />
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={trendData} barSize={14}>
                <XAxis dataKey="day" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: 'var(--tw-bg-opacity, #fff)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="Présents" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Retards"  fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Absents"  fill="#ef4444" radius={[4, 4, 0, 0]} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Pie chart today */}
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Aujourd'hui</h3>
                <p className="text-sm text-gray-500 mt-0.5">Répartition</p>
              </div>
              <Activity className="w-4 h-4 text-gray-400" />
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="45%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Terminaux + pointages récents */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* Terminaux */}
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Terminaux</h3>
            <div className="space-y-3">
              {devList.length === 0 && (
                <p className="text-sm text-gray-400">Aucun terminal configuré</p>
              )}
              {devList.map((d: any) => (
                <div key={d.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-2 h-2 rounded-full ${d.status === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-red-400'}`} />
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">{d.name}</div>
                      <div className="text-xs text-gray-400">{d.ip_address}</div>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${d.status === 'online' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                    {d.status === 'online' ? 'En ligne' : 'Hors ligne'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Pointages récents */}
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-800">
              <h3 className="font-semibold text-gray-900 dark:text-white">Pointages récents</h3>
              <a href="/attendance" className="text-xs text-indigo-600 hover:underline">Voir tout →</a>
            </div>
            <div className="divide-y divide-gray-50 dark:divide-gray-800">
              {records.slice(0, 6).map((r: any) => (
                <div key={r.id} className="flex items-center gap-4 px-5 py-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                    {r.employee?.first_name?.[0] || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {r.employee?.first_name} {r.employee?.last_name}
                    </div>
                    <div className="text-xs text-gray-400">{r.employee?.department?.name || r.date}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-mono font-semibold text-emerald-600">
                      {r.check_in || '—'}
                    </div>
                    <div className="text-xs text-gray-400">{r.check_out || 'En cours'}</div>
                  </div>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full shrink-0 ${
                    r.status === 'on_time' ? 'bg-emerald-100 text-emerald-700' :
                    r.status === 'late' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {r.status === 'on_time' ? 'À l\'heure' : r.status === 'late' ? 'Retard' : 'Absent'}
                  </span>
                </div>
              ))}
              {records.length === 0 && (
                <div className="px-5 py-8 text-center text-sm text-gray-400">
                  Aucun pointage enregistré
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
