import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Plus, Search, Upload, Download, Pencil, Trash2, X, Camera } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Input, Select } from '@/components/ui/Input'
import { Table, Pagination } from '@/components/ui/Table'
import { StatusBadge } from '@/components/ui/Badge'
import { Topbar } from '@/components/layout/Topbar'
import { employeesApi } from '@/lib/api'
import type { Employee } from '@/types'

const schema = z.object({
  matricule:   z.string().min(1),
  first_name:  z.string().min(1),
  last_name:   z.string().min(1),
  gender:      z.string().optional(),
  birth_date:  z.string().optional(),
  nationality: z.string().optional(),
  email:       z.string().email().optional().or(z.literal('')),
  phone:       z.string().optional(),
  address:     z.string().optional(),
  department_id: z.string().optional(),
  hire_date:   z.string().optional(),
  hourly_rate: z.coerce.number().min(0),
  badge_nfc:   z.string().optional(),
  status:      z.enum(['active', 'inactive', 'resigned']),
})
type FormData = z.infer<typeof schema>

export const Employees = () => {
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Employee | null>(null)

  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['employees', page, search, status],
    queryFn: () => employeesApi.list({ page, page_size: 15, search: search || undefined, status: status || undefined }),
  })

  const createMutation = useMutation({
    mutationFn: (d: FormData) => editing
      ? employeesApi.update(editing.id, d)
      : employeesApi.create(d),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['employees'] })
      setShowForm(false)
      setEditing(null)
      reset()
    }
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => employeesApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['employees'] }),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { hourly_rate: 312, status: 'active' }
  })

  const openEdit = (emp: Employee) => {
    setEditing(emp)
    reset({
      matricule:   emp.matricule,
      first_name:  emp.first_name,
      last_name:   emp.last_name,
      gender:      emp.gender || '',
      birth_date:  emp.birth_date || '',
      nationality: emp.nationality || '',
      email:       emp.email || '',
      phone:       emp.phone || '',
      address:     emp.address || '',
      hire_date:   emp.hire_date || '',
      hourly_rate: emp.hourly_rate,
      badge_nfc:   emp.badge_nfc || '',
      status:      emp.status as any,
    })
    setShowForm(true)
  }

  const cols = [
    {
      key: 'matricule', header: 'Matricule', width: 'w-28',
      render: (e: Employee) => (
        <span className="font-mono text-xs font-semibold text-indigo-600 dark:text-indigo-400">
          {e.matricule}
        </span>
      )
    },
    {
      key: 'name', header: 'Employé',
      render: (e: Employee) => (
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0"
            style={{ background: `hsl(${e.matricule.charCodeAt(4) * 20}, 60%, 55%)` }}>
            {e.photo_url
              ? <img src={e.photo_url} className="w-full h-full rounded-full object-cover" />
              : e.first_name[0]}
          </div>
          <div>
            <div className="font-medium text-gray-900 dark:text-white">
              {e.first_name} {e.last_name}
            </div>
            <div className="text-xs text-gray-400">{e.email || '—'}</div>
          </div>
        </div>
      )
    },
    { key: 'department', header: 'Département', render: (e: Employee) => e.department?.name || '—' },
    { key: 'phone', header: 'Téléphone' },
    {
      key: 'status', header: 'Statut',
      render: (e: Employee) => <StatusBadge status={e.status} />
    },
    {
      key: 'badge_nfc', header: 'Badge NFC',
      render: (e: Employee) => e.badge_nfc
        ? <span className="font-mono text-xs text-gray-500">{e.badge_nfc}</span>
        : <span className="text-gray-300">—</span>
    },
    {
      key: 'actions', header: '',
      render: (e: Employee) => (
        <div className="flex items-center gap-1">
          <button
            onClick={(ev) => { ev.stopPropagation(); openEdit(e) }}
            className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 hover:text-indigo-600 transition-colors"
          >
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={(ev) => {
              ev.stopPropagation()
              if (confirm(`Supprimer ${e.first_name} ${e.last_name} ?`)) deleteMutation.mutate(e.id)
            }}
            className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30 text-gray-500 hover:text-red-600 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      )
    },
  ]

  return (
    <>
      <Topbar
        title="Employés"
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" icon={<Download className="w-3.5 h-3.5" />}>
              Exporter
            </Button>
            <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => { setEditing(null); reset(); setShowForm(true) }}>
              Ajouter
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* Filtres */}
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 mb-4">
          <div className="flex items-center gap-3 p-4">
            <div className="flex-1 flex items-center gap-2 bg-gray-50 dark:bg-gray-800 rounded-xl px-3 py-2.5">
              <Search className="w-4 h-4 text-gray-400 shrink-0" />
              <input
                type="text"
                placeholder="Nom, matricule, email..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1) }}
                className="bg-transparent text-sm text-gray-700 dark:text-gray-300 placeholder:text-gray-400 outline-none w-full"
              />
            </div>
            <select
              value={status}
              onChange={(e) => { setStatus(e.target.value); setPage(1) }}
              className="px-3 py-2.5 text-sm rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Tous les statuts</option>
              <option value="active">Actif</option>
              <option value="inactive">Inactif</option>
              <option value="resigned">Démissionnaire</option>
            </select>
          </div>
          <Table
            columns={cols}
            data={data?.data?.items || []}
            loading={isLoading}
            emptyMessage="Aucun employé trouvé"
          />
          <Pagination
            page={page}
            pages={data?.data?.pages || 1}
            total={data?.data?.total || 0}
            pageSize={15}
            onChange={setPage}
          />
        </div>
      </div>

      {/* Drawer / Modal formulaire */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex">
          <div className="flex-1 bg-black/40" onClick={() => { setShowForm(false); setEditing(null) }} />
          <div className="w-full max-w-lg bg-white dark:bg-gray-900 h-full overflow-y-auto shadow-2xl">
            <div className="sticky top-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 px-6 py-4 flex items-center justify-between z-10">
              <h2 className="font-semibold text-gray-900 dark:text-white">
                {editing ? `Modifier — ${editing.first_name} ${editing.last_name}` : 'Nouvel employé'}
              </h2>
              <button onClick={() => { setShowForm(false); setEditing(null) }} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit((d) => createMutation.mutate(d))} className="p-6 space-y-5">
              <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl">
                <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-white text-2xl font-bold">
                  {editing?.first_name?.[0] || '?'}
                </div>
                <div className="text-white">
                  <div className="font-semibold text-lg">{editing ? `${editing.first_name} ${editing.last_name}` : 'Nouvel employé'}</div>
                  <div className="text-white/70 text-sm">{editing?.matricule || 'Matricule auto-généré'}</div>
                </div>
              </div>

              <fieldset className="space-y-3">
                <legend className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Identité</legend>
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Prénom" required {...register('first_name')} error={errors.first_name?.message} />
                  <Input label="Nom" required {...register('last_name')} error={errors.last_name?.message} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Matricule" required {...register('matricule')} error={errors.matricule?.message} />
                  <Select label="Genre" {...register('gender')}>
                    <option value="">—</option>
                    <option value="M">Masculin</option>
                    <option value="F">Féminin</option>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Date de naissance" type="date" {...register('birth_date')} />
                  <Input label="Nationalité" {...register('nationality')} placeholder="Algérienne" />
                </div>
              </fieldset>

              <fieldset className="space-y-3">
                <legend className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Contact</legend>
                <Input label="Email" type="email" {...register('email')} error={errors.email?.message} />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Téléphone" {...register('phone')} placeholder="+213 55..." />
                  <Input label="Badge NFC" {...register('badge_nfc')} className="font-mono" placeholder="A1B2C3D4" />
                </div>
              </fieldset>

              <fieldset className="space-y-3">
                <legend className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Poste</legend>
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Date d'embauche" type="date" {...register('hire_date')} />
                  <Input label="Taux horaire (DZD)" type="number" {...register('hourly_rate')} error={errors.hourly_rate?.message} />
                </div>
                <Select label="Statut" {...register('status')}>
                  <option value="active">Actif</option>
                  <option value="inactive">Inactif</option>
                  <option value="resigned">Démissionnaire</option>
                </Select>
              </fieldset>

              {createMutation.error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
                  {(createMutation.error as any)?.response?.data?.detail || 'Erreur lors de la sauvegarde'}
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <Button
                  type="button"
                  variant="secondary"
                  className="flex-1"
                  onClick={() => { setShowForm(false); setEditing(null) }}
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  className="flex-1"
                  loading={createMutation.isPending}
                >
                  {editing ? 'Modifier' : 'Créer l\'employé'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
