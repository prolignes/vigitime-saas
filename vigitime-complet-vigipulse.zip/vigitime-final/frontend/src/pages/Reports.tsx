import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend } from 'recharts'
import { Download, TrendingUp, Users, Clock, AlertTriangle } from 'lucide-react'
import { StatCard } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Topbar } from '@/components/layout/Topbar'
import { attendanceApi, employeesApi } from '@/lib/api'
import { format, subDays, subMonths } from 'date-fns'

const COLORS = ['#6366f1','#f59e0b','#ef4444','#10b981','#8b5cf6']

export const Reports = () => {
  const today   = format(new Date(), 'yyyy-MM-dd')
  const month_start = format(subDays(new Date(), 30), 'yyyy-MM-dd')

  const { data: attData } = useQuery({
    queryKey: ['reports', 'attendance'],
    queryFn: () => attendanceApi.list({ date_from: month_start, date_to: today, page_size: 500 }),
  })
  const { data: empData } = useQuery({
    queryKey: ['employees', 'all'],
    queryFn: () => employeesApi.list({ page_size: 100 }),
  })
  const { data: deptStats } = useQuery({
    queryKey: ['reports', 'dept'],
    queryFn: () => attendanceApi.deptStats({ date_from: month_start, date_to: today }),
  })

  const records = attData?.data?.items || attData?.data || []
  const employees = empData?.data?.items || []
  const depts: any[] = deptStats?.data || []

  // Calculs
  const present  = records.filter((r: any) => r.status !== 'absent').length
  const absent   = records.filter((r: any) => r.status === 'absent').length
  const late     = records.filter((r: any) => r.status === 'late').length
  const totalOT  = records.reduce((s: number, r: any) => s + (r.overtime_minutes || 0), 0)
  const avgRate  = employees.length ? Math.round(employees.reduce((s: number, e: any) => s + (e.rate || 95), 0) / employees.length) : 0

  // Trend 30 jours
  const trend = Array.from({ length: 14 }, (_, i) => {
    const d = format(subDays(new Date(), 13 - i), 'yyyy-MM-dd')
    const dayRec = records.filter((r: any) => r.date === d)
    return {
      day: format(subDays(new Date(), 13 - i), 'dd/MM'),
      Présents: dayRec.filter((r: any) => r.status !== 'absent').length,
      Retards:  dayRec.filter((r: any) => r.status === 'late').length,
      Absents:  dayRec.filter((r: any) => r.status === 'absent').length,
    }
  })

  const pieData = [
    { name: 'À l\'heure', value: present - late },
    { name: 'Retards',   value: late },
    { name: 'Absents',   value: absent },
  ].filter(d => d.value > 0)

  const exportCSV = () => {
    const rows = [
      ['Employé', 'Département', 'Date', 'Entrée', 'Sortie', 'Durée', 'H.Sup', 'Statut'],
      ...records.map((r: any) => [
        `${r.employee?.first_name} ${r.employee?.last_name}`,
        r.employee?.department?.name || '—',
        r.date, r.check_in || '—', r.check_out || '—',
        r.work_minutes ? `${Math.floor(r.work_minutes/60)}h${String(r.work_minutes%60).padStart(2,'0')}` : '—',
        r.overtime_minutes ? `${Math.floor(r.overtime_minutes/60)}h${String(r.overtime_minutes%60).padStart(2,'0')}` : '0h00',
        r.status
      ])
    ]
    const csv = '\uFEFF' + rows.map(r => r.join(';')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `vigitime_rapport_${today}.csv`
    a.click()
  }

  return (
    <>
      <Topbar title="Rapports" actions={
        <Button variant="secondary" size="sm" icon={<Download className="w-3.5 h-3.5" />} onClick={exportCSV}>
          Exporter CSV
        </Button>
      } />
      <div className="p-6 space-y-5">

        {/* KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Taux présence moyen" value={`${avgRate}%`} color="green" icon={<TrendingUp className="w-8 h-8" />} />
          <StatCard label="Total présents (30j)" value={present} color="blue" icon={<Users className="w-8 h-8" />} />
          <StatCard label="Heures sup. totales" value={`${Math.floor(totalOT/60)}h`} color="orange" icon={<Clock className="w-8 h-8" />} />
          <StatCard label="Absences (30j)" value={absent} color="red" icon={<AlertTriangle className="w-8 h-8" />} />
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Présence — 14 derniers jours</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={trend} barSize={12}>
                <XAxis dataKey="day" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                <Bar dataKey="Présents" fill="#6366f1" radius={[3,3,0,0]} />
                <Bar dataKey="Retards"  fill="#f59e0b" radius={[3,3,0,0]} />
                <Bar dataKey="Absents"  fill="#ef4444" radius={[3,3,0,0]} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Répartition (30j)</h3>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="45%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} stroke="none" />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '12px', borderRadius: '8px' }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tableau par département */}
        {depts.length > 0 && (
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800">
              <h3 className="font-semibold text-gray-900 dark:text-white">Présence par département</h3>
            </div>
            <div className="divide-y divide-gray-50 dark:divide-gray-800">
              {depts.map((d: any, i: number) => (
                <div key={i} className="flex items-center gap-4 px-5 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm">{d.department}</div>
                    <div className="text-xs text-gray-400">{d.employee_count} employés</div>
                  </div>
                  <div className="w-32">
                    <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{
                        width: `${d.attendance_rate}%`,
                        background: d.attendance_rate >= 90 ? '#10b981' : d.attendance_rate >= 75 ? '#f59e0b' : '#ef4444'
                      }} />
                    </div>
                  </div>
                  <div className="text-sm font-bold w-12 text-right" style={{
                    color: d.attendance_rate >= 90 ? '#10b981' : d.attendance_rate >= 75 ? '#f59e0b' : '#ef4444'
                  }}>
                    {d.attendance_rate}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  )
}
