import { useEffect, useState } from 'react'
import { Activity, AlertTriangle, TrendingDown, TrendingUp, Minus,
         Users, Heart, Brain, Zap, ChevronDown, ChevronUp } from 'lucide-react'
import { api } from '@/lib/api'

// ─── Types ───────────────────────────────────
interface EmployeePulse {
  employee_id:      string
  full_name:        string
  department:       string
  score:            number
  level:            'green' | 'orange' | 'red'
  risk_burnout:     number
  risk_absenteisme: number
  signals:          { code: string; label: string; severity: string }[]
  recommendation:   string
  trend:            'improving' | 'stable' | 'degrading'
  computed_at:      string
}

interface TenantPulse {
  global_score:     number
  total_employees:  number
  rouge:            number
  orange:           number
  vert:             number
  employees:        EmployeePulse[]
  teams:            any[]
}

// ─── Helpers ─────────────────────────────────
const levelColor = {
  green:  { bg: 'bg-emerald-50 dark:bg-emerald-950/40', text: 'text-emerald-700 dark:text-emerald-400', bar: '#10b981', border: 'border-emerald-200 dark:border-emerald-800' },
  orange: { bg: 'bg-amber-50 dark:bg-amber-950/40',     text: 'text-amber-700 dark:text-amber-400',     bar: '#f59e0b', border: 'border-amber-200 dark:border-amber-800'   },
  red:    { bg: 'bg-red-50 dark:bg-red-950/40',         text: 'text-red-700 dark:text-red-400',         bar: '#ef4444', border: 'border-red-200 dark:border-red-800'       },
}

const TrendIcon = ({ trend }: { trend: string }) => {
  if (trend === 'improving')  return <TrendingUp  className="w-4 h-4 text-emerald-500" />
  if (trend === 'degrading')  return <TrendingDown className="w-4 h-4 text-red-500" />
  return <Minus className="w-4 h-4 text-gray-400" />
}

const ScoreRing = ({ score, level }: { score: number; level: string }) => {
  const c   = levelColor[level as keyof typeof levelColor]
  const r   = 28
  const circ = 2 * Math.PI * r
  const dash = (score / 100) * circ
  return (
    <div className="relative w-20 h-20 flex items-center justify-center">
      <svg className="absolute inset-0 -rotate-90" width="80" height="80">
        <circle cx="40" cy="40" r={r} fill="none" stroke="currentColor" strokeWidth="5" className="text-gray-200 dark:text-gray-800" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={c.bar} strokeWidth="5"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round" />
      </svg>
      <span className={`text-lg font-bold z-10 ${c.text}`}>{score}</span>
    </div>
  )
}

// ─── Carte employé ────────────────────────────
const EmployeeCard = ({ emp }: { emp: EmployeePulse }) => {
  const [open, setOpen] = useState(false)
  const c = levelColor[emp.level]

  return (
    <div className={`rounded-xl border ${c.border} ${c.bg} p-4 transition-all`}>
      <div className="flex items-center gap-4">
        <ScoreRing score={emp.score} level={emp.level} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-gray-900 dark:text-white truncate">{emp.full_name}</span>
            <TrendIcon trend={emp.trend} />
          </div>
          <div className="text-xs text-gray-500 mb-2">{emp.department}</div>
          <div className="flex gap-3 text-xs">
            <span className="flex items-center gap-1">
              <Brain className="w-3 h-3 text-purple-500" />
              <span className="text-gray-600 dark:text-gray-400">Burnout {emp.risk_burnout}%</span>
            </span>
            <span className="flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" />
              <span className="text-gray-600 dark:text-gray-400">Absence J+14 {emp.risk_absenteisme}%</span>
            </span>
          </div>
        </div>
        {emp.signals.length > 0 && (
          <button onClick={() => setOpen(!open)}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors shrink-0">
            {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        )}
      </div>

      {open && (
        <div className="mt-3 pt-3 border-t border-gray-200/60 dark:border-gray-700/60 space-y-2">
          {emp.signals.map((s, i) => (
            <div key={i} className="flex items-start gap-2 text-xs">
              <AlertTriangle className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${
                s.severity === 'high' ? 'text-red-500' : 'text-amber-500'}`} />
              <span className="text-gray-700 dark:text-gray-300">{s.label}</span>
            </div>
          ))}
          <div className="mt-2 p-2 bg-white/60 dark:bg-gray-800/60 rounded-lg text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium text-gray-800 dark:text-gray-200">Recommandation : </span>
            {emp.recommendation}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Page principale VigiPulse ────────────────
export const VigiPulse = () => {
  const [data, setData]       = useState<TenantPulse | null>(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter]   = useState<'all' | 'red' | 'orange' | 'green'>('all')
  const [search, setSearch]   = useState('')

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get('/api/v1/vigipulse/tenant')
        setData(res.data)
      } catch {
        // données démo si API pas encore connectée
        setData(DEMO_DATA)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const filtered = (data?.employees || []).filter(e => {
    const matchFilter = filter === 'all' || e.level === filter
    const matchSearch = e.full_name.toLowerCase().includes(search.toLowerCase()) ||
                        e.department.toLowerCase().includes(search.toLowerCase())
    return matchFilter && matchSearch
  }).sort((a, b) => a.score - b.score)

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="flex items-center gap-3 text-gray-500">
        <Activity className="w-5 h-5 animate-pulse text-sky-500" />
        <span>Calcul VigiPulse en cours...</span>
      </div>
    </div>
  )

  const gs = data?.global_score || 0
  const gsColor = gs >= 75 ? 'text-emerald-600' : gs >= 50 ? 'text-amber-600' : 'text-red-600'

  return (
    <div className="p-6 max-w-5xl mx-auto">

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center">
            <Heart className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">VigiPulse</h1>
            <p className="text-xs text-gray-500">Bien-être prédictif — analyse 30 derniers jours</p>
          </div>
        </div>
        <div className="text-right">
          <div className={`text-3xl font-bold ${gsColor}`}>{gs}<span className="text-base text-gray-400">/100</span></div>
          <div className="text-xs text-gray-500">Score global entreprise</div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total employés', value: data?.total_employees || 0, icon: Users,         color: 'text-sky-600',     bg: 'bg-sky-50 dark:bg-sky-950/40'     },
          { label: 'En bonne santé', value: data?.vert   || 0, icon: Activity,      color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-950/40' },
          { label: 'À surveiller',   value: data?.orange || 0, icon: AlertTriangle,  color: 'text-amber-600',   bg: 'bg-amber-50 dark:bg-amber-950/40'     },
          { label: 'Risque élevé',   value: data?.rouge  || 0, icon: Brain,          color: 'text-red-600',     bg: 'bg-red-50 dark:bg-red-950/40'         },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className={`${bg} rounded-xl p-4 border border-gray-200/60 dark:border-gray-700/60`}>
            <Icon className={`w-5 h-5 ${color} mb-2`} />
            <div className={`text-2xl font-bold ${color}`}>{value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      {/* Barre de filtres + recherche */}
      <div className="flex items-center gap-3 mb-5">
        <input
          type="text"
          placeholder="Rechercher un employé..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
        />
        {(['all', 'red', 'orange', 'green'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
              filter === f
                ? f === 'all'    ? 'bg-sky-500 text-white'
                : f === 'red'    ? 'bg-red-500 text-white'
                : f === 'orange' ? 'bg-amber-500 text-white'
                : 'bg-emerald-500 text-white'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
            }`}>
            { f === 'all' ? 'Tous' : f === 'red' ? 'Risque élevé' : f === 'orange' ? 'À surveiller' : 'Équilibrés' }
          </button>
        ))}
      </div>

      {/* Liste employés */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-gray-400">Aucun employé trouvé</div>
        ) : (
          filtered.map(emp => <EmployeeCard key={emp.employee_id} emp={emp} />)
        )}
      </div>

      <p className="text-xs text-gray-400 text-center mt-6">
        VigiPulse — Analyse IA mise à jour chaque nuit à 02h00 · Données confidentielles RH
      </p>
    </div>
  )
}

// ─── Données démo (si API pas connectée) ─────
const DEMO_DATA: TenantPulse = {
  global_score: 67,
  total_employees: 6,
  rouge: 2, orange: 2, vert: 2,
  teams: [],
  employees: [
    { employee_id:'1', full_name:'Karim Boudiaf',    department:'Production',  score:28, level:'red',    risk_burnout:85, risk_absenteisme:72, trend:'degrading',
      signals:[{code:'SURCHARGE',label:'Surcharge chronique — 90 min/j heures sup',severity:'high'},{code:'RETARDS_AGGRAVATION',label:'Aggravation des retards sur 2 semaines',severity:'high'}],
      recommendation:'Intervention urgente. Entretien individuel cette semaine.', computed_at:'' },
    { employee_id:'2', full_name:'Amina Cherif',     department:'RH',          score:42, level:'red',    risk_burnout:65, risk_absenteisme:58, trend:'degrading',
      signals:[{code:'MICRO_ABSENCES',label:'3 congés maladie en 30 jours',severity:'high'}],
      recommendation:'Planifier un entretien bienveillant cette semaine.', computed_at:'' },
    { employee_id:'3', full_name:'Yacine Mebarki',   department:'Logistique',  score:55, level:'orange', risk_burnout:40, risk_absenteisme:35, trend:'stable',
      signals:[{code:'RETARDS_FREQUENTS',label:'Retards fréquents — 25% des jours',severity:'medium'}],
      recommendation:'Entretien informel recommandé. Vérifier la charge.', computed_at:'' },
    { employee_id:'4', full_name:'Nadia Belkacem',   department:'Production',  score:61, level:'orange', risk_burnout:30, risk_absenteisme:25, trend:'improving',
      signals:[{code:'DEPART_ANTICIPE',label:'Temps de travail moyen insuffisant — 5.8h/j',severity:'medium'}],
      recommendation:'Surveiller la tendance. Score en amélioration.', computed_at:'' },
    { employee_id:'5', full_name:'Sofiane Hamidi',   department:'Logistique',  score:82, level:'green',  risk_burnout:10, risk_absenteisme:8,  trend:'stable',
      signals:[], recommendation:'Employé équilibré. Continuer le suivi mensuel.', computed_at:'' },
    { employee_id:'6', full_name:'Rania Ould-Saïd',  department:'RH',          score:91, level:'green',  risk_burnout:5,  risk_absenteisme:4,  trend:'improving',
      signals:[], recommendation:'Excellent profil. Peut être mentore pour l\'équipe.', computed_at:'' },
  ]
}
