import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Clock, LogIn, LogOut, PauseCircle, Calendar, FileText, DollarSign } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Table } from '@/components/ui/Table'
import { StatusBadge } from '@/components/ui/Badge'
import { StatCard } from '@/components/ui/Card'
import { employeesApi, attendanceApi } from '@/lib/api'
import { format, subDays } from 'date-fns'

export const SelfService = () => {
  const [step, setStep]         = useState<'login' | 'dashboard'>('login')
  const [matricule, setMatricule] = useState('')
  const [employee, setEmployee]  = useState<any>(null)
  const [activeTab, setActiveTab] = useState('punch')
  const [error, setError]        = useState('')
  const [punchResult, setPunchResult] = useState<string | null>(null)

  const qc = useQueryClient()

  const login = async () => {
    if (!matricule.trim()) return
    try {
      const res = await employeesApi.list({ search: matricule.trim(), page_size: 5 })
      const found = (res.data?.items || []).find((e: any) =>
        e.matricule.toUpperCase() === matricule.trim().toUpperCase()
      )
      if (!found) { setError('Matricule introuvable'); return }
      setEmployee(found)
      setStep('dashboard')
      setError('')
    } catch {
      setError('Erreur de connexion')
    }
  }

  const { data: attData } = useQuery({
    queryKey: ['ss-attendance', employee?.id],
    queryFn: () => attendanceApi.list({
      employee_id: employee.id,
      date_from: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
      date_to: format(new Date(), 'yyyy-MM-dd'),
      page_size: 50,
    }),
    enabled: !!employee?.id,
  })
  const { data: leavesData } = useQuery({
    queryKey: ['ss-leaves', employee?.id],
    queryFn: () => attendanceApi.leaves.list({ employee_id: employee.id }),
    enabled: !!employee?.id,
  })
  const { data: statsData } = useQuery({
    queryKey: ['ss-stats', employee?.id],
    queryFn: () => employeesApi.get(employee.id).then(r => attendanceApi.deptStats({
      date_from: format(subDays(new Date(), 30), 'yyyy-MM-dd'),
      date_to: format(new Date(), 'yyyy-MM-dd'),
    })),
    enabled: !!employee?.id,
  })

  const punchMutation = useMutation({
    mutationFn: (type: 'in' | 'out') => {
      const now = format(new Date(), 'HH:mm')
      const today = format(new Date(), 'yyyy-MM-dd')
      return attendanceApi.create({
        employee_id: employee.id,
        date: today,
        check_in:  type === 'in'  ? now : undefined,
        check_out: type === 'out' ? now : undefined,
        method: 'self_service',
      })
    },
    onSuccess: (_, type) => {
      const now = format(new Date(), 'HH:mm')
      setPunchResult(`${type === 'in' ? 'Entrée' : 'Sortie'} enregistrée à ${now}`)
      qc.invalidateQueries({ queryKey: ['ss-attendance'] })
    }
  })
  const leavesMutation = useMutation({
    mutationFn: (d: any) => attendanceApi.leaves.create(d),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['ss-leaves'] }),
  })

  const records = attData?.data?.items || attData?.data || []
  const leaves  = leavesData?.data || []
  const today   = format(new Date(), 'yyyy-MM-dd')
  const todayRec = records.find((r: any) => r.date === today)
  const workH = records.reduce((s: number, r: any) => s + (r.work_minutes || 0), 0)
  const otH   = records.reduce((s: number, r: any) => s + (r.overtime_minutes || 0), 0)
  const absent = records.filter((r: any) => r.status === 'absent').length
  const fmtDur = (m: number) => `${Math.floor(m/60)}h${String(m%60).padStart(2,'0')}`

  if (step === 'login') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950 p-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-indigo-600/20">
              <Clock className="w-9 h-9 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Espace Employé</h1>
            <p className="text-gray-400 text-sm mt-1">Identifiez-vous avec votre matricule</p>
          </div>
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-6 shadow-sm">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                  Matricule
                </label>
                <input
                  type="text"
                  value={matricule}
                  onChange={e => setMatricule(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && login()}
                  placeholder="EMP-001"
                  className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-center font-mono text-lg tracking-wider focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              {error && <p className="text-red-500 text-sm text-center">{error}</p>}
              <Button className="w-full justify-center py-3 text-base" onClick={login}>
                Accéder à mon espace
              </Button>
            </div>
            <div className="mt-5 pt-4 border-t border-gray-100 dark:border-gray-800">
              <p className="text-xs text-gray-400 text-center mb-3">Accès rapide démo</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {['EMP-001','EMP-002','EMP-003','EMP-004'].map(m => (
                  <button key={m} onClick={() => { setMatricule(m); setTimeout(login, 50) }}
                    className="px-3 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-mono font-medium transition-colors">
                    {m}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-700 px-6 py-5">
        <div className="flex items-center justify-between max-w-3xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-white text-lg font-bold">
              {employee?.first_name?.[0]}{employee?.last_name?.[0]}
            </div>
            <div>
              <div className="text-white font-bold text-lg">{employee?.first_name} {employee?.last_name}</div>
              <div className="text-white/70 text-sm">{employee?.matricule}</div>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-white/80 hover:text-white hover:bg-white/10"
            onClick={() => { setStep('login'); setEmployee(null); setMatricule('') }}>
            Déconnexion
          </Button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto p-6 space-y-5">
        {/* Tabs */}
        <div className="flex gap-1 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-1">
          {[
            { id: 'punch',   label: 'Pointage',   icon: Clock },
            { id: 'history', label: 'Historique',  icon: FileText },
            { id: 'leaves',  label: 'Congés',      icon: Calendar },
          ].map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveTab(id)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                activeTab === id ? 'bg-indigo-600 text-white' : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}>
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {/* Tab Pointage */}
        {activeTab === 'punch' && (
          <div className="space-y-4">
            {/* Stats */}
            <div className="grid grid-cols-3 gap-3">
              <StatCard label="H. travaillées (30j)" value={fmtDur(workH)} color="blue" icon={<Clock className="w-6 h-6" />} />
              <StatCard label="H. supplémentaires"   value={fmtDur(otH)}  color="orange" icon={<Clock className="w-6 h-6" />} />
              <StatCard label="Absences"              value={`${absent}j`} color="red"    icon={<Clock className="w-6 h-6" />} />
            </div>

            {/* Pointage aujourd'hui */}
            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-6">
              <div className="flex items-center justify-between mb-5">
                <h3 className="font-semibold text-gray-900 dark:text-white">Aujourd'hui — {format(new Date(), 'dd/MM/yyyy')}</h3>
                <div className="text-right">
                  {todayRec ? (
                    <div>
                      {todayRec.check_in  && <div className="text-emerald-600 font-mono font-bold">↑ {todayRec.check_in}</div>}
                      {todayRec.check_out && <div className="text-gray-500 font-mono text-sm">↓ {todayRec.check_out}</div>}
                    </div>
                  ) : (
                    <div className="text-gray-400 text-sm">Pas encore pointé</div>
                  )}
                </div>
              </div>

              {punchResult && (
                <div className="mb-5 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center">
                  <div className="text-emerald-700 font-bold text-lg">✓ {punchResult}</div>
                </div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={() => { setPunchResult(null); punchMutation.mutate('in') }}
                  disabled={punchMutation.isPending || !!(todayRec?.check_in)}
                  className="flex-1 flex flex-col items-center gap-2 py-5 bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-200 hover:border-emerald-400 rounded-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed group">
                  <LogIn className="w-8 h-8 text-emerald-600" />
                  <span className="font-bold text-emerald-700">Entrée</span>
                  {todayRec?.check_in && <span className="text-xs text-emerald-500">Déjà pointé à {todayRec.check_in}</span>}
                </button>
                <button
                  onClick={() => { setPunchResult(null); punchMutation.mutate('out') }}
                  disabled={punchMutation.isPending || !!(todayRec?.check_out) || !todayRec?.check_in}
                  className="flex-1 flex flex-col items-center gap-2 py-5 bg-red-50 hover:bg-red-100 border-2 border-red-200 hover:border-red-400 rounded-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                  <LogOut className="w-8 h-8 text-red-600" />
                  <span className="font-bold text-red-700">Sortie</span>
                  {todayRec?.check_out && <span className="text-xs text-red-500">Pointé à {todayRec.check_out}</span>}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab Historique */}
        {activeTab === 'history' && (
          <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800">
              <h3 className="font-semibold text-gray-900 dark:text-white">Mes pointages — 30 derniers jours</h3>
            </div>
            <div className="divide-y divide-gray-50 dark:divide-gray-800">
              {records.slice(0, 20).map((r: any) => (
                <div key={r.id} className="flex items-center gap-4 px-5 py-3">
                  <div className="text-sm text-gray-500 w-24 font-mono shrink-0">{r.date}</div>
                  <div className="font-mono text-sm font-semibold text-emerald-600 w-16">{r.check_in || '—'}</div>
                  <div className="font-mono text-sm text-gray-400 w-16">{r.check_out || '—'}</div>
                  <div className="text-sm text-gray-500 flex-1">
                    {r.work_minutes ? fmtDur(r.work_minutes) : '—'}
                    {r.overtime_minutes > 0 && <span className="text-amber-600 ml-2 text-xs">+{fmtDur(r.overtime_minutes)} sup.</span>}
                  </div>
                  <StatusBadge status={r.status} />
                </div>
              ))}
              {records.length === 0 && (
                <div className="px-5 py-8 text-center text-gray-400">Aucun pointage</div>
              )}
            </div>
          </div>
        )}

        {/* Tab Congés */}
        {activeTab === 'leaves' && (
          <div className="space-y-4">
            {/* Solde */}
            <div className="grid grid-cols-3 gap-3">
              <StatCard label="Congés payés restants" value="24j" color="green"  icon={<Calendar className="w-6 h-6" />} />
              <StatCard label="Maladie restants"      value="15j" color="blue"   icon={<Calendar className="w-6 h-6" />} />
              <StatCard label="Demandes en attente"   value={`${leaves.filter((l:any)=>l.status==='pending').length}`} color="orange" icon={<Calendar className="w-6 h-6" />} />
            </div>

            {/* Nouvelle demande */}
            <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Nouvelle demande de congé</h3>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Type</label>
                  <select id="ss-lv-type"
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="vacation">Congés payés</option>
                    <option value="sick">Maladie</option>
                    <option value="personal">Personnel</option>
                  </select>
                </div>
                <div />
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Du</label>
                  <input type="date" id="ss-lv-from" defaultValue={today}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Au</label>
                  <input type="date" id="ss-lv-to" defaultValue={today}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <textarea id="ss-lv-reason" rows={2} placeholder="Motif (optionnel)"
                className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none mb-3" />
              <Button className="w-full justify-center"
                loading={leavesMutation.isPending}
                onClick={() => leavesMutation.mutate({
                  employee_id: employee.id,
                  leave_type: (document.getElementById('ss-lv-type') as HTMLSelectElement).value,
                  start_date: (document.getElementById('ss-lv-from') as HTMLInputElement).value,
                  end_date:   (document.getElementById('ss-lv-to')   as HTMLInputElement).value,
                  reason:     (document.getElementById('ss-lv-reason') as HTMLTextAreaElement).value,
                })}>
                Soumettre la demande
              </Button>
            </div>

            {/* Mes demandes */}
            {leaves.length > 0 && (
              <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
                <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-800">
                  <h3 className="font-semibold text-gray-900 dark:text-white">Mes demandes</h3>
                </div>
                <div className="divide-y divide-gray-50 dark:divide-gray-800">
                  {leaves.map((l: any) => (
                    <div key={l.id} className="flex items-center gap-3 px-5 py-3">
                      <div className="flex-1">
                        <div className="text-sm font-medium">{l.start_date} → {l.end_date}</div>
                        <div className="text-xs text-gray-400">{l.working_days}j · {l.leave_type}</div>
                      </div>
                      <StatusBadge status={l.status} />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
