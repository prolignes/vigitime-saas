import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { Clock, Plus, RefreshCw, Download, Filter } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Table, Pagination } from '@/components/ui/Table'
import { StatusBadge } from '@/components/ui/Badge'
import { StatCard } from '@/components/ui/Card'
import { Topbar } from '@/components/layout/Topbar'
import { attendanceApi, employeesApi } from '@/lib/api'
import type { AttendanceRecord } from '@/types'
import { format, subDays } from 'date-fns'

export const Attendance = () => {
  const [page, setPage] = useState(1)
  const [dateFrom, setDateFrom] = useState(format(subDays(new Date(), 7), 'yyyy-MM-dd'))
  const [dateTo,   setDateTo]   = useState(format(new Date(), 'yyyy-MM-dd'))
  const [statusFilter, setStatus] = useState('')
  const [showPunch, setShowPunch] = useState(false)

  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['attendance', page, dateFrom, dateTo, statusFilter],
    queryFn: () => attendanceApi.list({ page, page_size: 20, date_from: dateFrom, date_to: dateTo, status: statusFilter || undefined }),
  })

  const { data: employees } = useQuery({
    queryKey: ['employees', 'all'],
    queryFn: () => employeesApi.list({ page_size: 100, status: 'active' }),
  })

  const punchMutation = useMutation({
    mutationFn: (d: any) => attendanceApi.create(d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['attendance'] }); setShowPunch(false) }
  })

  const records: AttendanceRecord[] = data?.data?.items || data?.data || []
  const total: number = data?.data?.total || records.length

  const present  = records.filter(r => r.status !== 'absent').length
  const late     = records.filter(r => r.status === 'late').length
  const absent   = records.filter(r => r.status === 'absent').length
  const overtime = records.reduce((s, r) => s + (r.overtime_minutes || 0), 0)

  const fmtTime = (t?: string) => t || '—'
  const fmtDur  = (min: number) => min ? `${Math.floor(min/60)}h${String(min%60).padStart(2,'0')}` : '—'

  const cols = [
    {
      key: 'employee', header: 'Employé',
      render: (r: AttendanceRecord) => (
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
            {(r as any).employee?.first_name?.[0] || '?'}
          </div>
          <div>
            <div className="font-medium text-sm">{(r as any).employee?.first_name} {(r as any).employee?.last_name}</div>
            <div className="text-xs text-gray-400">{(r as any).employee?.department?.name || '—'}</div>
          </div>
        </div>
      )
    },
    { key: 'date', header: 'Date', render: (r: AttendanceRecord) => (
      <span className="font-mono text-xs">{r.date}</span>
    )},
    { key: 'check_in', header: 'Entrée', render: (r: AttendanceRecord) => (
      <span className="font-mono text-sm font-semibold text-emerald-600">{fmtTime(r.check_in)}</span>
    )},
    { key: 'check_out', header: 'Sortie', render: (r: AttendanceRecord) => (
      <span className="font-mono text-sm text-gray-500">{fmtTime(r.check_out)}</span>
    )},
    { key: 'work_minutes', header: 'Durée', render: (r: AttendanceRecord) => fmtDur(r.work_minutes) },
    { key: 'overtime_minutes', header: 'H.Sup', render: (r: AttendanceRecord) => (
      <span className={r.overtime_minutes > 0 ? 'text-amber-600 font-semibold' : 'text-gray-300'}>
        {fmtDur(r.overtime_minutes)}
      </span>
    )},
    { key: 'status', header: 'Statut', render: (r: AttendanceRecord) => <StatusBadge status={r.status} /> },
    { key: 'method', header: 'Méthode', render: (r: AttendanceRecord) => (
      <span className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-medium">{r.method}</span>
    )},
  ]

  return (
    <>
      <Topbar
        title="Pointages"
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" icon={<Download className="w-3.5 h-3.5" />}>CSV</Button>
            <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowPunch(true)}>
              Pointage manuel
            </Button>
          </div>
        }
      />
      <div className="p-6 space-y-5">

        {/* KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Présents" value={present} color="green" icon={<Clock className="w-8 h-8" />} />
          <StatCard label="Retards" value={late} color="orange" icon={<Clock className="w-8 h-8" />} />
          <StatCard label="Absents" value={absent} color="red" icon={<Clock className="w-8 h-8" />} />
          <StatCard label="H.Sup totales" value={fmtDur(overtime)} color="purple" icon={<Clock className="w-8 h-8" />} />
        </div>

        {/* Table */}
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
          <div className="flex flex-wrap items-center gap-3 p-4 border-b border-gray-100 dark:border-gray-800">
            <input type="date" value={dateFrom} onChange={e => { setDateFrom(e.target.value); setPage(1) }}
              className="px-3 py-2 text-sm rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <span className="text-gray-400 text-sm">→</span>
            <input type="date" value={dateTo} onChange={e => { setDateTo(e.target.value); setPage(1) }}
              className="px-3 py-2 text-sm rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            <select value={statusFilter} onChange={e => { setStatus(e.target.value); setPage(1) }}
              className="px-3 py-2 text-sm rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option value="">Tous les statuts</option>
              <option value="on_time">À l'heure</option>
              <option value="late">Retard</option>
              <option value="absent">Absent</option>
            </select>
            <button onClick={() => qc.invalidateQueries({ queryKey: ['attendance'] })}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500 transition-colors">
              <RefreshCw className="w-4 h-4" />
            </button>
            <span className="ml-auto text-sm text-gray-400">{total} enregistrement(s)</span>
          </div>
          <Table columns={cols} data={records} loading={isLoading} emptyMessage="Aucun pointage pour cette période" />
          <Pagination page={page} pages={Math.max(1, Math.ceil(total / 20))} total={total} pageSize={20} onChange={setPage} />
        </div>
      </div>

      {/* Modal pointage manuel */}
      {showPunch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowPunch(false)} />
          <div className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h2 className="font-semibold text-lg text-gray-900 dark:text-white mb-5">Pointage manuel</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Employé</label>
                <select id="mp-employee"
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">-- Sélectionner --</option>
                  {(employees?.data?.items || []).map((e: any) => (
                    <option key={e.id} value={e.id}>{e.matricule} — {e.first_name} {e.last_name}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Date</label>
                  <input type="date" id="mp-date" defaultValue={format(new Date(), 'yyyy-MM-dd')}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Type</label>
                  <select id="mp-type"
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option value="check_in">Entrée</option>
                    <option value="check_out">Sortie</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Heure</label>
                <input type="time" id="mp-time" defaultValue={format(new Date(), 'HH:mm')}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button variant="secondary" className="flex-1" onClick={() => setShowPunch(false)}>Annuler</Button>
              <Button className="flex-1"
                loading={punchMutation.isPending}
                onClick={() => {
                  const empId = (document.getElementById('mp-employee') as HTMLSelectElement).value
                  const date  = (document.getElementById('mp-date') as HTMLInputElement).value
                  const time  = (document.getElementById('mp-time') as HTMLInputElement).value
                  const type  = (document.getElementById('mp-type') as HTMLSelectElement).value
                  if (!empId || !date || !time) return
                  punchMutation.mutate({
                    employee_id: empId, date,
                    check_in:  type === 'check_in'  ? time : undefined,
                    check_out: type === 'check_out' ? time : undefined,
                    method: 'manual'
                  })
                }}>
                Enregistrer
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
