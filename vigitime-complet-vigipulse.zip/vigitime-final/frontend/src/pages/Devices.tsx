import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Monitor, Plus, RefreshCw, Wifi, WifiOff, Zap } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Table } from '@/components/ui/Table'
import { StatusBadge } from '@/components/ui/Badge'
import { StatCard } from '@/components/ui/Card'
import { Topbar } from '@/components/layout/Topbar'
import { devicesApi } from '@/lib/api'
import type { Device } from '@/types'

export const Devices = () => {
  const [showAdd, setShowAdd] = useState(false)
  const [pinging, setPinging] = useState<string | null>(null)
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['devices'],
    queryFn: () => devicesApi.list(),
    refetchInterval: 30000,
  })

  const pingMutation = useMutation({
    mutationFn: (id: string) => devicesApi.ping(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['devices'] }),
    onSettled: () => setPinging(null),
  })
  const syncMutation = useMutation({
    mutationFn: (id: string) => devicesApi.sync(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['devices'] }),
  })

  const devices: Device[] = data?.data || []
  const online  = devices.filter(d => d.status === 'online').length
  const offline = devices.filter(d => d.status === 'offline').length
  const totalRec = devices.reduce((s, d) => s + d.total_records, 0)

  const cols = [
    {
      key: 'status', header: 'État', width: 'w-20',
      render: (d: Device) => (
        <div className="flex items-center gap-2">
          <div className={`w-2.5 h-2.5 rounded-full ${d.status === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-red-400'}`} />
          <span className={`text-xs font-semibold ${d.status === 'online' ? 'text-emerald-600' : 'text-red-500'}`}>
            {d.status === 'online' ? 'En ligne' : 'Hors ligne'}
          </span>
        </div>
      )
    },
    { key: 'name', header: 'Nom', render: (d: Device) => (
      <div>
        <div className="font-semibold text-sm">{d.name}</div>
        <div className="text-xs text-gray-400">{d.model} — {d.brand}</div>
      </div>
    )},
    { key: 'ip_address', header: 'Adresse IP', render: (d: Device) => (
      <span className="font-mono text-sm font-semibold text-indigo-600">{d.ip_address}:{d.port}</span>
    )},
    { key: 'area', header: 'Zone', render: (d: Device) => (
      <span className="bg-blue-50 text-blue-700 text-xs px-2 py-0.5 rounded-full font-medium">{d.area || '—'}</span>
    )},
    { key: 'firmware', header: 'Firmware', render: (d: Device) => (
      <span className="font-mono text-xs text-gray-400">{d.firmware || '—'}</span>
    )},
    { key: 'total_records', header: 'Enregistrements', render: (d: Device) => (
      <span className="font-semibold text-amber-600">{d.total_records.toLocaleString()}</span>
    )},
    { key: 'last_sync_at', header: 'Dernier sync', render: (d: Device) => (
      <span className="text-xs text-gray-400">{d.last_sync_at || 'Jamais'}</span>
    )},
    {
      key: 'actions', header: '',
      render: (d: Device) => (
        <div className="flex gap-1">
          <button
            onClick={() => { setPinging(d.id); pingMutation.mutate(d.id) }}
            disabled={pinging === d.id}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 font-medium transition-colors disabled:opacity-50"
          >
            {pinging === d.id ? '...' : 'Ping'}
          </button>
          <button
            onClick={() => syncMutation.mutate(d.id)}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 font-medium transition-colors"
          >
            Sync
          </button>
        </div>
      )
    },
  ]

  return (
    <>
      <Topbar
        title="Terminaux ZKTeco"
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" icon={<RefreshCw className="w-3.5 h-3.5" />}
              onClick={() => qc.invalidateQueries({ queryKey: ['devices'] })}>
              Rafraîchir
            </Button>
            <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowAdd(true)}>
              Ajouter terminal
            </Button>
          </div>
        }
      />
      <div className="p-6 space-y-5">

        {/* KPIs */}
        <div className="grid grid-cols-3 gap-4">
          <StatCard label="En ligne" value={online} color="green" icon={<Wifi className="w-8 h-8" />} />
          <StatCard label="Hors ligne" value={offline} color="red" icon={<WifiOff className="w-8 h-8" />} />
          <StatCard label="Total enregistrements" value={totalRec.toLocaleString()} color="blue" icon={<Zap className="w-8 h-8" />} />
        </div>

        {/* Table */}
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-800">
            <h3 className="font-semibold text-gray-900 dark:text-white">
              {devices.length} terminal(ux) configuré(s)
            </h3>
            {/* ADMS info */}
            <div className="text-xs text-gray-400 bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-lg">
              Protocole ADMS Push :
              <span className="font-mono text-indigo-600 ml-1">POST /api/v1/adms/push</span>
            </div>
          </div>
          <Table
            columns={cols}
            data={devices}
            loading={isLoading}
            emptyMessage="Aucun terminal configuré — ajoutez votre premier terminal ZKTeco"
          />
        </div>

        {/* Guide connexion */}
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 p-5">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-3">Configuration ADMS Cloud (recommandé)</h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2 text-gray-600 dark:text-gray-400">
              <p className="font-medium text-gray-900 dark:text-white">Sur le terminal ZKTeco :</p>
              <p>1. Menu → Comm → Cloud Server</p>
              <p>2. Server Address → <span className="font-mono text-indigo-600">votre-domaine.com</span></p>
              <p>3. Server Port → <span className="font-mono text-indigo-600">80</span></p>
              <p>4. Protocol → <span className="font-mono text-indigo-600">ADMS</span></p>
              <p>5. Sauvegarder et redémarrer</p>
            </div>
            <div className="bg-gray-900 rounded-xl p-4 font-mono text-xs text-green-400 space-y-1">
              <p className="text-gray-400"># Endpoint ADMS VigiTime</p>
              <p>POST /api/v1/adms/push</p>
              <p className="text-gray-400 mt-2"># Les pointages arrivent en temps réel</p>
              <p className="text-gray-400"># Aucun proxy local requis</p>
              <p className="text-yellow-400 mt-2"># Compatible :</p>
              <p>ZKTeco firmware ≥ 6.60</p>
              <p>Hikvision ISAPI</p>
              <p>Dahua HTTP Push</p>
            </div>
          </div>
        </div>
      </div>

      {/* Modal ajout terminal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowAdd(false)} />
          <div className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h2 className="font-semibold text-lg text-gray-900 dark:text-white mb-5">Ajouter un terminal</h2>
            <div className="space-y-4">
              {[
                { id: 'dev-name',  label: 'Nom',         placeholder: 'Entrée principale',  type: 'text' },
                { id: 'dev-ip',    label: 'Adresse IP',  placeholder: '192.168.1.201',       type: 'text' },
                { id: 'dev-port',  label: 'Port TCP',    placeholder: '4370',                type: 'number' },
                { id: 'dev-model', label: 'Modèle',      placeholder: 'SpeedFace-V5L',       type: 'text' },
                { id: 'dev-brand', label: 'Marque',      placeholder: 'ZKTeco',              type: 'text' },
                { id: 'dev-area',  label: 'Zone',        placeholder: 'Bâtiment A',          type: 'text' },
              ].map(f => (
                <div key={f.id}>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{f.label}</label>
                  <input id={f.id} type={f.type} placeholder={f.placeholder}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono" />
                </div>
              ))}
            </div>
            <p className="text-xs text-gray-400 mt-4">
              Après l'ajout, cliquez sur "Ping" pour tester la connexion TCP.
            </p>
            <div className="flex gap-3 mt-5">
              <Button variant="secondary" className="flex-1" onClick={() => setShowAdd(false)}>Annuler</Button>
              <Button className="flex-1" onClick={() => setShowAdd(false)}>Sauvegarder</Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
