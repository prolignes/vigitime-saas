import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Plus, Check, X } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Table } from '@/components/ui/Table'
import { StatusBadge, Badge } from '@/components/ui/Badge'
import { Topbar } from '@/components/layout/Topbar'
import { attendanceApi, employeesApi } from '@/lib/api'
import type { LeaveRequest } from '@/types'
import { format } from 'date-fns'

const LEAVE_TYPES: Record<string, string> = {
  vacation: 'Congés payés', sick: 'Maladie',
  personal: 'Personnel', maternity: 'Maternité'
}

export const Leaves = () => {
  const [statusFilter, setStatus] = useState('')
  const [showForm, setShowForm] = useState(false)
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['leaves', statusFilter],
    queryFn: () => attendanceApi.leaves.list({ status: statusFilter || undefined }),
  })
  const { data: employees } = useQuery({
    queryKey: ['employees', 'all'],
    queryFn: () => employeesApi.list({ page_size: 100, status: 'active' }),
  })

  const approveMutation = useMutation({
    mutationFn: (id: string) => attendanceApi.leaves.approve(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leaves'] })
  })
  const rejectMutation = useMutation({
    mutationFn: (id: string) => attendanceApi.leaves.reject(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leaves'] })
  })
  const createMutation = useMutation({
    mutationFn: (d: any) => attendanceApi.leaves.create(d),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['leaves'] }); setShowForm(false) }
  })

  const leaves: LeaveRequest[] = data?.data || []
  const pending = leaves.filter(l => l.status === 'pending').length

  const cols = [
    { key: 'employee', header: 'Employé', render: (l: LeaveRequest) => (
      <div className="font-medium">{(l as any).employee?.first_name} {(l as any).employee?.last_name}</div>
    )},
    { key: 'leave_type', header: 'Type', render: (l: LeaveRequest) => (
      <Badge variant={l.leave_type === 'sick' ? 'red' : l.leave_type === 'vacation' ? 'green' : 'blue'}>
        {LEAVE_TYPES[l.leave_type] || l.leave_type}
      </Badge>
    )},
    { key: 'start_date', header: 'Du', render: (l: LeaveRequest) => <span className="font-mono text-xs">{l.start_date}</span> },
    { key: 'end_date', header: 'Au', render: (l: LeaveRequest) => <span className="font-mono text-xs">{l.end_date}</span> },
    { key: 'working_days', header: 'Jours', render: (l: LeaveRequest) => <span className="font-semibold">{l.working_days}j</span> },
    { key: 'reason', header: 'Motif', render: (l: LeaveRequest) => <span className="text-gray-400 text-xs">{l.reason || '—'}</span> },
    { key: 'status', header: 'Statut', render: (l: LeaveRequest) => <StatusBadge status={l.status} /> },
    {
      key: 'actions', header: '',
      render: (l: LeaveRequest) => l.status === 'pending' ? (
        <div className="flex gap-1">
          <button onClick={() => approveMutation.mutate(l.id)}
            className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-colors" title="Approuver">
            <Check className="w-3.5 h-3.5" />
          </button>
          <button onClick={() => rejectMutation.mutate(l.id)}
            className="p-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors" title="Refuser">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : null
    },
  ]

  return (
    <>
      <Topbar title="Congés" actions={
        <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowForm(true)}>
          Nouvelle demande
        </Button>
      } />
      <div className="p-6">
        <div className="bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-3 p-4 border-b border-gray-100 dark:border-gray-800">
            {['', 'pending', 'approved', 'rejected'].map(s => (
              <button key={s} onClick={() => setStatus(s)}
                className={`px-3 py-1.5 text-sm rounded-lg font-medium transition-colors ${
                  statusFilter === s
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}>
                {s === '' ? 'Toutes' : s === 'pending' ? `En attente${pending > 0 ? ` (${pending})` : ''}` : s === 'approved' ? 'Approuvées' : 'Refusées'}
              </button>
            ))}
          </div>
          <Table columns={cols} data={leaves} loading={isLoading} emptyMessage="Aucune demande de congé" />
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowForm(false)} />
          <div className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h2 className="font-semibold text-lg text-gray-900 dark:text-white mb-5">Nouvelle demande de congé</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Employé</label>
                <select id="lv-emp" className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">-- Sélectionner --</option>
                  {(employees?.data?.items || []).map((e: any) => (
                    <option key={e.id} value={e.id}>{e.matricule} — {e.first_name} {e.last_name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Type</label>
                <select id="lv-type" className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  {Object.entries(LEAVE_TYPES).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Du</label>
                  <input type="date" id="lv-from" defaultValue={format(new Date(), 'yyyy-MM-dd')}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Au</label>
                  <input type="date" id="lv-to" defaultValue={format(new Date(), 'yyyy-MM-dd')}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">Motif</label>
                <textarea id="lv-reason" rows={2}
                  className="w-full px-3 py-2.5 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                  placeholder="Raison de la demande..." />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button variant="secondary" className="flex-1" onClick={() => setShowForm(false)}>Annuler</Button>
              <Button className="flex-1" loading={createMutation.isPending}
                onClick={() => {
                  const emp    = (document.getElementById('lv-emp') as HTMLSelectElement).value
                  const type   = (document.getElementById('lv-type') as HTMLSelectElement).value
                  const from   = (document.getElementById('lv-from') as HTMLInputElement).value
                  const to     = (document.getElementById('lv-to') as HTMLInputElement).value
                  const reason = (document.getElementById('lv-reason') as HTMLTextAreaElement).value
                  if (!emp || !from || !to) return
                  createMutation.mutate({ employee_id: emp, leave_type: type, start_date: from, end_date: to, reason })
                }}>
                Soumettre
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
