import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Clock, Eye, EyeOff, Loader2, ShieldCheck } from 'lucide-react'
import { authApi } from '@/lib/api'
import { useAuthStore } from '@/lib/store'

const schema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(6, 'Minimum 6 caractères'),
})

type FormData = z.infer<typeof schema>

export const Login = () => {
  const navigate = useNavigate()
  const { setAuth } = useAuthStore()
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState('')

  const { register, handleSubmit, formState: { errors, isSubmitting }, setValue } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async (data: FormData) => {
    setError('')
    try {
      const res = await authApi.login(data.email, data.password)
      const { access_token, refresh_token, user } = res.data
      setAuth(user, access_token, refresh_token)
      navigate('/dashboard', { replace: true })
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Identifiants incorrects')
    }
  }

  const quickLogin = (role: string) => {
    const creds: Record<string, { email: string; password: string }> = {
      admin: { email: 'admin@vigitime.dz', password: 'admin123' },
      rh:    { email: 'rh@vigitime.dz',    password: 'rh123' },
      sup:   { email: 'sup@vigitime.dz',    password: 'sup123' },
    }
    if (creds[role]) {
      setValue('email', creds[role].email)
      setValue('password', creds[role].password)
    }
  }

  return (
    <div className="min-h-screen flex bg-gray-950">
      {/* Left panel — branding */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 bg-gradient-to-br from-[#060D1F] via-[#0C1A3A] to-[#060D1F] p-12">
        <div className="flex items-center gap-3">
          <img src="/logo_vigitime.png" alt="VigiTime" className="w-10 h-10 object-contain" />
          <span className="text-white text-xl font-bold">Vigi<span style={{color:'#38BDF8'}}>Time</span></span>
        </div>

        <div>
          <h1 className="text-4xl font-bold text-white leading-tight mb-4">
            Gestion de présence<br />
            <span className="text-sky-400">nouvelle génération</span>
          </h1>
          <p className="text-gray-400 text-lg mb-10">
            Connectez vos terminaux ZKTeco, gérez vos équipes et générez vos rapports en temps réel.
          </p>
          <div className="grid grid-cols-2 gap-4">
            {[
              { n: '100%', l: 'Compatible ZKTeco' },
              { n: 'Multi', l: 'Tenant SaaS' },
              { n: 'FR/AR', l: 'Bilingue' },
              { n: 'API', l: 'REST complète' },
            ].map(({ n, l }) => (
              <div key={l} className="bg-white/5 rounded-xl p-4 border border-white/10">
                <div className="text-sky-400 text-xl font-bold">{n}</div>
                <div className="text-gray-400 text-sm mt-1">{l}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-gray-600 text-sm">
          <ShieldCheck className="w-4 h-4" />
          Données hébergées en Algérie — Conformité CNIL
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-white dark:bg-gray-900">
        <div className="w-full max-w-md">
          <div className="flex items-center gap-3 mb-8 lg:hidden">
            <img src="/logo_vigitime.png" alt="VigiTime" className="w-10 h-10 object-contain" />
            <span className="text-gray-900 dark:text-white text-xl font-bold">Vigi<span style={{color:'#0EA5E9'}}>Time</span></span>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Connexion</h2>
          <p className="text-gray-500 mb-8">Accédez à votre espace de gestion</p>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                Email / Identifiant
              </label>
              <input
                {...register('email')}
                type="email"
                placeholder="admin@vigitime.dz"
                className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm transition-all"
              />
              {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email.message}</p>}
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Mot de passe
                </label>
                <button type="button" className="text-xs text-sky-500 hover:underline">
                  Mot de passe oublié ?
                </button>
              </div>
              <div className="relative">
                <input
                  {...register('password')}
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm pr-11 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25 disabled:opacity-60"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {isSubmitting ? 'Connexion...' : 'Se connecter'}
            </button>
          </form>

          {/* Accès rapide démo */}
          <div className="mt-8">
            <div className="flex items-center gap-3 mb-3">
              <div className="h-px flex-1 bg-gray-200 dark:bg-gray-800" />
              <span className="text-xs text-gray-400">Accès démo rapide</span>
              <div className="h-px flex-1 bg-gray-200 dark:bg-gray-800" />
            </div>
            <div className="flex gap-2">
              {[
                { role: 'admin', label: 'Super Admin', color: 'bg-sky-50 text-sky-700 hover:bg-sky-100' },
                { role: 'rh', label: 'Resp. RH', color: 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' },
                { role: 'sup', label: 'Superviseur', color: 'bg-amber-50 text-amber-700 hover:bg-amber-100' },
              ].map(({ role, label, color }) => (
                <button
                  key={role}
                  onClick={() => quickLogin(role)}
                  className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-colors ${color}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
